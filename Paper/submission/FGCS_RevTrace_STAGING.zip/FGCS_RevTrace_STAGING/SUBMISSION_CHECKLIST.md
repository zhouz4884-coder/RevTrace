# FGCS submission checklist

- [x] Elsevier `elsarticle` double-column manuscript.
- [x] 18 pages including figures, tables, and references.
- [x] Abstract below 250 words; six English keywords.
- [x] Five highlights, each no more than 85 characters.
- [x] Cover letter and separate title page.
- [x] Competing-interest, AI-use, acknowledgments, and data statements.
- [x] Seven figures supplied as separate logically named files.
- [x] LaTeX source archive with editable tables and bibliography.
- [x] CJK replay, denominator, and contract-inventory audits pass.
- [x] Corrected senior-author Figure 2 inserted.
- [ ] Corrected senior-author Figures 1 and 3 inserted and package rebuilt.
- [ ] Corresponding-author phone supplied.
- [ ] Suggested reviewers completed if requested by Editorial Manager.
- [ ] Final author approval and generated-PDF inspection.
