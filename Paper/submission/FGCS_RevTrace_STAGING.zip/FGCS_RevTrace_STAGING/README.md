# RevTrace FGCS submission staging package

This directory is upload-structured but **not yet final**. It becomes ready
after the final PDF, cover letter, and declarations are approved by all
authors.

The manuscript is frozen at 18 pages. The package contains the manuscript PDF,
title page, cover letter, highlights, separate figures, LaTeX source zip,
declarations, audit evidence, and editorial-input templates.

Build command:

```powershell
python scripts/build_fgcs_submission_package.py --phone "<phone>" --figures-final
```

The figure filenames referenced by LaTeX are stable, so corrected artwork can
replace the existing files without changing manuscript layout.
