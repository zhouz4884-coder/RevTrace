# RevTrace FGCS submission staging package

This directory is upload-structured but **not yet final**. It becomes ready
after the final PDF, cover letter, and declarations are approved by all
authors.

The manuscript is frozen at 18 pages. The upload-facing manuscript PDF is the
double-blind build (`main_blind.pdf`). Author names, affiliations, and contact
details appear only in the separate title page. The LaTeX source zip retains
the author-identifying production source and must not be uploaded during
double-blind review unless the editorial office explicitly requests it.

Build command:

```powershell
python scripts/build_fgcs_submission_package.py --phone "<phone>" --figures-final
```

The figure filenames referenced by LaTeX are stable, so corrected artwork can
replace the existing files without changing manuscript layout.
