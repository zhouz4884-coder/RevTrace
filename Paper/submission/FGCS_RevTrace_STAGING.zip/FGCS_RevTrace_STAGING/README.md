# RevTrace FGCS submission staging package

This directory is upload-structured but **not yet final**. It becomes ready
after the corrected senior-author Figures 1 and 3 are supplied, the package
builder is rerun, and the final PDF is
visually approved.

The manuscript is frozen at 18 pages. The package contains the manuscript PDF,
title page, cover letter, highlights, separate figures, LaTeX source zip,
declarations, audit evidence, and editorial-input templates.

Build command:

```powershell
python scripts/build_fgcs_submission_package.py --phone "<phone>"
```

The figure filenames referenced by LaTeX are stable, so corrected artwork can
replace the existing files without changing manuscript layout.
