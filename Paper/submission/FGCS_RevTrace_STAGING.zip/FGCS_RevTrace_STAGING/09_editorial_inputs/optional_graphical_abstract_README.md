# Optional graphical abstract

The verified FGCS materials available to this package builder do not establish
that a graphical abstract is mandatory for every regular-paper submission.
If Editorial Manager requests one, use the corrected senior-author Figure 1
source and export a dedicated 1328x531-pixel-or-larger graphical abstract.
Do not upload an AI-generated graphical abstract.
