# Pending before upload

- [ ] Replace Figures 1 and 3 with the corrected senior-author exports listed in Paper/figures/SENIOR_FIGURE_CHANGE_REQUEST.md.
- [ ] Have all authors approve the final PDF, cover letter, and declarations.
