# Pending before upload

- [ ] Have all authors approve the final PDF, cover letter, and declarations.
