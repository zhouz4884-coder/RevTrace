# Pending before upload

- [ ] Replace Figures 1--3 with the corrected senior-author exports listed in Paper/figures/SENIOR_FIGURE_CHANGE_REQUEST.md.
- [ ] Supply the corresponding-author phone number on the title page.
- [ ] Have all authors approve the final PDF, cover letter, and declarations.
