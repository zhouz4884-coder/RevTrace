def parse_asr_output(raw):
    return 1
