print(2)
