import json,subprocess,sys,time,hashlib
from pathlib import Path
B=Path(sys.argv[1]);R=Path(__file__).resolve().parents[1];O=B/'results/revtrace/phaseD_20261021/R1_gpu';O.mkdir(exist_ok=False)
CODE=json.loads((R/'SOURCE_MANIFEST.json').read_text())['code_commit'];done=[]
matrix=[(repeat,mode,hold) for repeat in range(3) for mode in ['fine_certified','coarse'] for hold in ([0,.75,1.5] if repeat%2==0 else [1.5,.75,0])]
(O/'RUN_MATRIX.json').write_text(json.dumps(matrix,indent=2))
try:
 for repeat,mode,hold in matrix:
  assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
  name=f'{mode}-hold{hold}-r{repeat}';c=[sys.executable,'-u',str(R/'scripts/run_tc_live_qwen.py'),'--model',str(B/'models/Qwen3-ASR-1.7B'),'--manifest',str(B/'datasets/tc_live_20260906/manifest.json'),'--output',str(O/name),'--code-commit',CODE,'--study-id','PHASE-D-R1-DELIVERY','--mode',mode,'--sessions','16','--proposal-barrier','decoupled','--proposal-reconciliation','lazy','--display-protocol','canonical-snapshot-v1','--publish-canonical-display','--authority-result-delay',str(hold),'--phase-n-instrumentation','--capture-model-inputs','--durable-journal-path',str(O/'journals'/(name+'.wal')),'--journal-sync-mode','group_ready']
  with (O/(name+'.log')).open('w') as f:r=subprocess.run(c,cwd=R,stdout=f,stderr=subprocess.STDOUT)
  assert r.returncode==0,name
  done.append(name);(O/'PROGRESS.json').write_text(json.dumps({'completed':done,'expected':18}));print(name,flush=True)
 (O/'SUMMARY.json').write_text(json.dumps({'status':'COMPLETE','completed':done}))
except BaseException as e:
 (O/'STOP.json').write_text(json.dumps({'error':repr(e),'completed':done}));raise
