"""Meaningful parser/render rejection checks; no model, network or GPU."""
import hashlib,json,struct
import pytest
from audit_recovery import frames,render


def frame(row):
    b=json.dumps(row).encode();return struct.pack('>I',len(b))+b+hashlib.sha256(b).digest()


def test_checksum_and_chain_reject_tampered_committed_evidence(tmp_path):
    p=tmp_path/'wal';a={'sequence':0,'previous_sha256':'','kind':'init'}
    p.write_bytes(frame(a));assert frames(p)==[a]
    bad=bytearray(p.read_bytes());bad[-1]^=1;p.write_bytes(bad)
    with pytest.raises(AssertionError):frames(p)


def test_sequence_gap_is_not_silently_recovered(tmp_path):
    p=tmp_path/'wal';p.write_bytes(frame({'sequence':1,'previous_sha256':''}))
    with pytest.raises(AssertionError):frames(p)


class Tok:
    def decode(self,z,**kw):return ''.join(chr(x) for x in z if x!=0)
    def encode(self,s):return [ord(x) for x in s]


def parser(s,**kw):return 'English',s


def test_render_uses_actual_job_parent_instead_of_cached_text():
    j=dict(prompt_tokens=list(map(ord,'abcdefg')),chunk_id=2,language='English')
    P,text=render(Tok(),parser,j,[ord('Z'),0],{0})
    assert text=='abZ' and P==list(map(ord,'abZ'))


def test_early_eos_and_short_unterminated_sequences_fail_closed():
    j=dict(prompt_tokens=[],chunk_id=0,language='English')
    with pytest.raises(AssertionError):render(Tok(),parser,j,[0,65],{0})
    with pytest.raises(AssertionError):render(Tok(),parser,j,[65],{0})
