"""Coordinate and real-cost obligations; CPU fixtures only."""
import pytest
from paid_context_probe import whisper_interval,charge_missing_prefix,cut_window
from audit_legacy_contracts import catastrophic


def test_ten_second_probe_preserves_native_two_second_chunk_coordinate():
    j=whisper_interval(30*16000,40*16000)
    assert j['chunk_id']==15 and j['chunk_id']*32000==j['audio_start_sample']
    assert j['end_window']==20
    with pytest.raises(ValueError):whisper_interval(1,160000)
    with pytest.raises(ValueError):whisper_interval(160000,160000)


def test_reanchor_also_pays_for_a_missing_trusted_prefix():
    reanchor={'paid_lease_seconds':2.};charge_missing_prefix(reanchor,7.)
    assert reanchor['model_work_with_missing_prefix_seconds']==9.
    assert reanchor['missing_accepted_history_not_closed_by_capsule']


def test_old_failure_cut_is_diagnostic_and_ordinary_control_remains_fixed():
    row={'efsc_trace':[dict(window_index=5,terminated_by_eos=True,candidate_token_ids=[1],prompt_tokens_for_proposal=0),dict(window_index=2,terminated_by_eos=True,candidate_token_ids=[1],prompt_tokens_for_proposal=0)]}
    assert cut_window(row,True)==2 and cut_window(row,False)==3


def test_catastrophic_tail_definition_retains_both_original_branches():
    assert catastrophic(22.,11.)  # >10pp
    assert catastrophic(7.,1.)   # >2x and>5pp
    assert not catastrophic(5.,1.)
