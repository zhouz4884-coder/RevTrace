"""One bounded schema-clarity control; no task oracle generation, no installs."""
from pathlib import Path
import argparse,copy,hashlib,importlib.metadata,json,os,platform,subprocess,sys,time,traceback


CLARIFY={
 'runbook': 'Field semantics: dependencies maps an action to its prerequisite actions, not its successors. An empty prerequisite list is immediately eligible. A prerequisite must already be in the valid completed prefix before this request. The returned completed list must be that prefix plus exactly the chosen next action (if one is eligible). last_action must be the appended action, not an unrecorded future action. Do not append a prerequisite and its dependent in the same one-action request.',
 'resource_plan': 'Field semantics: cost consumes capacity and value is the objective. Maximize the SUM of values of newly added jobs, not their value/cost ratio. Compare feasible subsets containing at most max_new_jobs new jobs; the limit is a count of jobs, not a cost. The returned reserved list includes the preserved prefix followed by the chosen subset. remaining equals the declared capacity minus the total cost of all returned reservations.'
}


def clarified(messages,family):
    m=copy.deepcopy(messages);assert m[0]['role']=='system' and m[-1]['role']=='user'
    m[0]['content']+=' '+CLARIFY[family]
    return m


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True)
    p.add_argument('--runtime',type=Path,required=True);p.add_argument('--runtime-manifest',type=Path,required=True);p.add_argument('--config',type=Path,required=True)
    p.add_argument('--model-manifest',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);a=p.parse_args()
    source=json.loads(a.source_manifest.read_text());runtime=json.loads(a.runtime_manifest.read_text())
    for r in source['files']:assert sha(Path(__file__).parent/r['path'])==r['sha256']
    for r in runtime['files']:assert sha(a.runtime/r['path'])==r['sha256']
    assert not a.out.exists() and not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    a.out.mkdir(parents=True)
    def put(n,x):
        with (a.out/n).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
    config=json.loads(a.config.read_text())['provider'];config['model_manifest']=str(a.model_manifest)
    refs=[json.loads((a.reference/'operator_self_check'/f'{task}.json').read_text()) for task in ['ops-dev-0','resource-dev-0']]
    env=dict(python=sys.version,platform=platform.platform(),packages={n:importlib.metadata.version(n) for n in ['torch','transformers']});put('ENVIRONMENT.json',env)
    put('FREEZE.json',dict(experiment_id='REVTRACE-NATIVE-SCHEMA-CLARITY-PAID-PROBE-20261028',source_commit=source['code_commit'],runtime_commit=runtime['code_commit'],source_manifest_sha256=sha(a.source_manifest),runtime_manifest_sha256=sha(a.runtime_manifest),environment_sha256=sha(a.out/'ENVIRONMENT.json'),config=config,model_manifest_sha256=sha(a.model_manifest),clarifications=CLARIFY,order=[['original',0],['clarified',0],['clarified',1],['original',1]],actual_expected_calls=8,tasks='two original development initial requests only; four validation instances untouched',scope='single prospective prompt-schema control, not model/RevTrace innovation or deployed task results',raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'SUMMARY.json'),gate_decision_location=str(a.out/'GATE.json')))
    sys.path[:0]=[str(a.runtime/'native_lifecycle')]
    from actual_provider import ActualModel,load_asset_manifest
    from native_power import PowerSampler
    from tasks import development_tasks,score
    config['verified_asset_sha256']=load_asset_manifest(a.model_manifest,config['model_path']);os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    rows=[];power=PowerSampler(a.out/'power.jsonl')
    try:
        started=time.perf_counter();model=ActualModel(config,'authority',1,'float32');put('LOAD.json',dict(seconds=time.perf_counter()-started,contract=model.contract))
        for task,ref in zip(development_tasks(),refs):
            assert model.input_ids(ref['request']['messages'])==ref['request']['input_ids']
            for variant,repeat in [('original',0),('clarified',0),('clarified',1),('original',1)]:
                m=ref['request']['messages'] if variant=='original' else clarified(ref['request']['messages'],task['family']);ids=model.input_ids(m)
                start=time.perf_counter();r=model.generate(ids,'schema-clarity-'+variant);end=time.perf_counter()
                row=dict(task=task['id'],family=task['family'],variant=variant,repeat=repeat,messages=m,request_ids=ids,result=r,both_GPU_energy=power.finish_interval(start,end),quality=score(task['family'],task['source'],task['initial_memory'],task['requests'][0],r['value']))
                rows.append(row);put(f'{task["id"]}-{variant}-r{repeat}.json',row)
        put('SUMMARY.json',dict(status='COMPLETE_BOUNDED_SCHEMA_CLARITY_OPERATOR',rows=rows,application_installs=0,scope='first-request operator only; not validation or multi-cycle success'))
        put('GATE.json',dict(gate='DIAGNOSTIC_RECORDED_NOT_AUTOMATIC_MATRIX_GO',rows=len(rows),GPU_calls=len(rows),source_commit=source['code_commit']))
    except BaseException:
        put('STOP.json',dict(completed=rows,error=traceback.format_exc()));raise
    finally:power.close()


if __name__=='__main__':main()
