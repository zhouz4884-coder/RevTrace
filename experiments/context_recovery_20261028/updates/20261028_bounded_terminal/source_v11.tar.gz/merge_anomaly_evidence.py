"""Keep per-anomaly cross-contract uncertainty and cap denominators explicit."""
from pathlib import Path
import argparse,csv,hashlib,json,platform,sys


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def cap_counts(case,checked):
    full=case['controls'][0];cut=case['case']['cut_window']
    prefix=sum(bool(checked[x]['capped']) for x in full['calls'][:cut]);rows=[]
    for c in case['controls']:
        paid=sum(bool(checked[x]['capped']) for x in c['calls'])
        reused=prefix if c['phase'] in ['stored_checkpoint','clear_at_cut','after_reanchor'] else 0
        capsule=int(bool(checked[c['calls'][0]]['capped'])) if c['phase']=='after_reanchor' else 0
        rows.append(dict(session_id=case['case']['session_id'],control=c['phase'],paid_call_cap_events=paid,
                         inherited_prefix_cap_events=reused,reanchor_conditioning_only_cap_events=capsule,
                         evaluated_transcript_cap_events=reused+paid-capsule))
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--legacy',type=Path,required=True);p.add_argument('--audit',type=Path,required=True)
    p.add_argument('--study',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
    own=json.loads(a.source_manifest.read_text())
    for f in own['files']:assert sha(Path(__file__).parent/f['path'])==f['sha256']
    assert not a.out.exists();a.out.mkdir(parents=True)
    def put(n,x):
        with (a.out/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
    files=dict(legacy=a.legacy/'RESULT.json',audit=a.audit/'RESULT.json',study=a.study/'SUMMARY.json')
    legacy,audit,study=[json.loads(files[k].read_text()) for k in ['legacy','audit','study']]
    assert len(legacy['roots'])==11 and audit['cases']==len(study['cases'])==14
    env=dict(python=sys.version,platform=platform.platform());put('ENVIRONMENT.json',env)
    put('FREEZE.json',dict(experiment_id='REVTRACE-ANOMALY-CROSS-CONTRACT-INTEGRATION-20261028',source_commit=own['code_commit'],source_manifest_sha256=sha(a.source_manifest),inputs={k:sha(v) for k,v in files.items()},environment_sha256=sha(a.out/'ENVIRONMENT.json'),raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'RESULT.json'),gate_decision_location=str(a.out/'GATE.json'),GPU_calls=0))
    current={(r['session_id'],r['control']):r for r in audit['rows']};cuts={c['case']['session_id']:c['case']['cut_window'] for c in study['cases']};rows=[]
    for r in legacy['roots']:
        sid=r['session_id'];v=r['recorded_WER'];b=current[sid,'full_reference']
        rows.append(dict(session_id=sid,legacy_speakers=len({s.split('-')[0] for s in r['utterance_ids']}),legacy_utterances=len(r['utterance_ids']),legacy_canonical_WER=v['canonical'],legacy_EFSC_WER=v['efsc'],legacy_feedback_off_WER=v['feedback_off'],legacy_empty_prompt_windows=len(r['prompt_empty_windows']),legacy_low_yield_EOS_events=len(r['low_yield_EOS_windows']),R8_byte_bound_views=sum(x['source_quality_byte_bound'] for x in r['r8_views']),R9_exact_complete_input_matches=len(r['r9_same_complete_input_matches']),current_operator_cut=cuts[sid],current_native_WER=b['WER'],current_checkpoint_delta_WER=current[sid,'stored_checkpoint']['WER']-b['WER'],current_rebuild_delta_WER=current[sid,'missing_prefix_rebuild']['WER']-b['WER'],current_clear_delta_WER=current[sid,'clear_at_cut']['WER']-b['WER'],current_reanchor_delta_WER=current[sid,'after_reanchor']['WER']-b['WER'],causal_status='original per-case cause unresolved; current controlled input/conditioning effects measured under a different frozen realization'))
    checked={r['id']:r for r in audit['checked_calls']};caps=[r for c in study['cases'] for r in cap_counts(c,checked)]
    totals={m:{k:sum(r[k] for r in caps if r['control']==m) for k in ['paid_call_cap_events','inherited_prefix_cap_events','reanchor_conditioning_only_cap_events','evaluated_transcript_cap_events']} for m in sorted({r['control'] for r in caps})}
    put('RESULT.json',dict(status='COMPLETE_SCOPED_PER_ANOMALY_EVIDENCE_MATRIX',rows=rows,cap_event_scope_rows=caps,cap_totals=totals,GPU_calls=0,claim_boundary='No original FAST_COMMIT anomaly is certified fixed by changed FP32/batch1/256 inputs; no online ancestry/quality guarantee follows from the operator segment log'))
    with (a.out/'PER_ANOMALY_MATRIX.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    put('GATE.json',dict(gate='PASS_CROSS_CONTRACT_AND_CAP_DENOMINATOR_INTEGRATION',original_R7_anomalies=11,current_paid_sources=14,source_commit=own['code_commit'],GPU_calls=0))
    print(json.dumps(dict(roots=len(rows),cap_totals=totals)))


if __name__=='__main__':main()
