"""Paid context-recovery feasibility controls, not a new VACC/R9 algorithm.

Uses the frozen native FP32 Whisper executor with an explicitly declared
conventional decoder-capacity control. Transformed-context outputs
are evaluated through a declared segment log; they are NEVER relabelled as
installed v7 Canonical text. No-loss/restored and rebuilt parents are repeated
with actual generation. The acquisition of a trusted anchor is charged.
"""
from pathlib import Path
import argparse,copy,hashlib,importlib.metadata,json,os,platform,re,subprocess,sys,time,traceback


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4194304),b''):h.update(b)
    return h.hexdigest()


def object_sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def cut_window(row,is_root):
    if is_root:
        bad=[e['window_index'] for e in row['efsc_trace'] if e['window_index']>=1 and e['terminated_by_eos'] and len(e['candidate_token_ids'])<=10 and e['prompt_tokens_for_proposal']==0]
        if bad:return min(bad)
    return 3


def segment_words(text):return re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?",text.lower())


def edit_distance(a,b):
    last=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1):row.append(min(row[-1]+1,last[j]+1,last[j-1]+(x!=y)))
        last=row
    return last[-1]


def whisper_interval(start,end):
    if type(start) is not int or type(end) is not int or start<0 or start>=end or start%32000:
        raise ValueError('native interval must use its declared2s sample coordinate')
    return dict(chunk_id=start//32000,end_window=(end+31999)//32000,audio_start_sample=start,audio_end_sample=end)


def charge_missing_prefix(control,acquisition):
    if acquisition<0 or control['paid_lease_seconds']<0:raise ValueError('negative paid work')
    control['if_no_preexisting_trusted_prefix_add_acquisition_seconds']=acquisition
    control['model_work_with_missing_prefix_seconds']=acquisition+control['paid_lease_seconds']
    control['missing_accepted_history_not_closed_by_capsule']=True


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--analysis-manifest',type=Path,required=True);p.add_argument('--runtime-source',type=Path,required=True);p.add_argument('--runtime-manifest',type=Path,required=True)
    p.add_argument('--input-identity',type=Path,required=True);p.add_argument('--legacy-trace',type=Path,required=True);p.add_argument('--model',type=Path,required=True)
    p.add_argument('--whisper-context-policy',choices=['unbounded-native-v1','reserve-generation-tail-v1'],required=True)
    a=p.parse_args();B=Path('/media/user/5bc0dc8d-c938-4b2a-af1b-94174fc511a9')
    assert a.out.resolve().is_relative_to(B/'results/revtrace/freeze_boundary_20261027') and not a.out.exists()
    assert a.data_root.resolve().is_relative_to(B/'datasets/revtrace')
    own=json.loads(a.analysis_manifest.read_text());rt=json.loads(a.runtime_manifest.read_text())
    for r in own['files']:assert sha(Path(__file__).parent/r['path'])==r['sha256']
    for r in rt['files']:assert sha(a.runtime_source/r['path'])==r['sha256']
    assert sha(a.input_identity)=='fcaea19e95c8a720e43e2edd9ad407fb4b9a43526239cc1157045a3bdcbf8802'
    assert sha(a.legacy_trace)=='a61c24ebdc7239bd6df31ae5d70a80359b05a3a44c770cc82dad19d39107a034'
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    a.out.mkdir(parents=True);a.data_root.mkdir(parents=True,exist_ok=True)
    def put(name,x):
        with (a.out/name).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
    identity=json.loads(a.input_identity.read_text());trace={r['session_id']:r for r in json.loads(a.legacy_trace.read_text())['sessions']}
    roots=[2,8,22,32,41,54,57,78,90,95,122];selected=roots+[0,1,3];inputs={r['session_id']:r for r in identity['session_records']}
    cases=[dict(session_id=sid,is_legacy_root=sid in roots,cut_window=cut_window(trace[sid],sid in roots)) for sid in selected]
    env=dict(python=sys.version,platform=platform.platform(),packages={n:importlib.metadata.version(n) for n in ['torch','transformers','numpy','soundfile','tokenizers']})
    model_files={p.name:sha(p) for p in sorted(a.model.iterdir()) if p.is_file() and p.suffix in ['.json','.txt','.safetensors','.bin','.model']}
    assert any(x.endswith('.safetensors') or x.endswith('.bin') for x in model_files)
    put('ENVIRONMENT.json',env);put('MODEL_ASSETS.json',model_files)
    specification=dict(experiment_id='REVTRACE-PAID-NATIVE-CONTEXT-FEASIBILITY-20261028',analysis_commit=own['code_commit'],analysis_manifest_sha256=sha(a.analysis_manifest),runtime_commit=rt['code_commit'],runtime_manifest_sha256=sha(a.runtime_manifest),environment_sha256=sha(a.out/'ENVIRONMENT.json'),model_assets_sha256=sha(a.out/'MODEL_ASSETS.json'),cases=cases,model_dtype='float32',physical_batch_rows=1,token_budget=256,audio_window_seconds=10,whisper_context_policy=a.whisper_context_policy,resource_lifecycle='one warm shared FP32 Authority Worker onGPU1; startup separately measured; bothGPU board energy; no coldRTO claim',legacy_scope='all eleven historical anomalies plus three ordinary diagnostic controls; old FP16/margin96-token/16-row records are not faithfully reproduced',controls=['full_native_reference','existing_checkpoint_restore','full_missing_prefix_rebuild','clear_conditioning_at_cut','past20s_audio_reanchor_existing_VACC_style_baseline'],conditioning_scope='conventional capacity control shared by all arms; full model inputs declared; transformed variants use evaluation segment log, not v7 Canonical publication',raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'SUMMARY.json'),gate_decision_location=str(a.out/'GATE.json'))
    put('FREEZE.json',specification);worker=None;power=None;calls=[];outcomes=[]
    try:
        import numpy as np,soundfile as sf
        sys.path[:0]=[str(a.runtime_source/'runtime/src'),str(a.runtime_source/'runtime/scripts'),str(a.runtime_source)]
        from row_delivery_executor import RowGPUExecutor
        from revtrace.dgft import digest_tokens
        from revtrace.whisper_adapter import TrustedWhisperRender,whisper_conditioning_config
        from memory_gpu_pilot import Power
        from transformers import WhisperProcessor
        processor=WhisperProcessor.from_pretrained(a.model,local_files_only=True);tok=processor.tokenizer
        conditioning=whisper_conditioning_config(a.model,a.whisper_context_policy)
        render=TrustedWhisperRender(processor,256,conditioning)
        waveforms={};manifest=[]
        for case in cases:
            sid=case['session_id'];r=inputs[sid];audio=np.zeros(r['samples'],dtype='<f4')
            for part in r['layout']:
                if part['kind']!='utterance':continue
                assert sha(part['path'])==part['sha256']
                x,rate=sf.read(part['path'],dtype='float32');assert rate==16000 and len(x)==part['end']-part['start'];audio[part['start']:part['end']]=x
            assert hashlib.sha256(audio.tobytes()).hexdigest()==r['float32le_sha256']
            path=a.data_root/f'legacy-session-{sid}.wav'
            if path.exists():
                x,rate=sf.read(path,dtype='float32');assert rate==16000 and np.array_equal(x,audio)
            else:sf.write(path,audio,16000,format='WAV',subtype='FLOAT')
            waveforms[sid]=audio;manifest.append(dict(source_id=f'legacy-{sid}',path=str(path),language='English',duration=90.,reference=r['reference'],audio_sha256=r['float32le_sha256']))
        put('manifest.json',dict(sessions=manifest))
        contract=object_sha(specification);runtime=object_sha(dict(model_assets=model_files,adapter='whisper-get_prompt_ids-v1',conditioning=conditioning,dtype='float32',budget=256,segment_seconds=10))
        config=dict(gpu=1,model=str(a.model),model_adapter='whisper',dtype='float32',manifest=str(a.out/'manifest.json'),microbatch=1,max_new_tokens=256,whisper_context_policy=a.whisper_context_policy,whisper_conditioning=conditioning,runtime_digest=runtime,capture_model_inputs=True,row_delivery='row',receipt_trace_path=str(a.out/'worker-receipts.jsonl'))
        power=Power(a.out/'power.jsonl');started=time.perf_counter();worker=RowGPUExecutor('context-authority-1',config);worker.wait_ready()
        put('WORKER_READY.json',dict(ready=worker.ready,initialization_seconds=time.perf_counter()-started))
        def call(sid,phase,index,start,end,P,parent):
            audio=waveforms[sid];jid=f'context-{sid}-{phase}-{index}-{len(calls)}'
            interval=whisper_interval(start,end);assert end<=len(audio)
            job=dict(job_id=jid,session_id=sid,source_id=f'legacy-{sid}',role='authority',language='English',contract_epoch=1,contract_digest=contract,runtime_digest=runtime,parent=parent,parent_prompt_digest=digest_tokens(P),prompt_tokens=list(P),chunk_id=start//32000,chunk_advance=(end-start)//32000,end_window=(end+31999)//32000,audio_start_sample=start,audio_end_sample=end,prefix_audio_sha256=hashlib.sha256(audio[:end].tobytes()).hexdigest(),interval_audio_sha256=hashlib.sha256(audio[start:end].tobytes()).hexdigest(),audio_ready_perf=time.perf_counter()-1.,enqueue_perf=time.perf_counter())
            assert all(job[k]==v for k,v in interval.items())
            assert job['chunk_id']*32000==job['audio_start_sample']
            before=time.perf_counter();worker.submit([job]);received=[];events=[];limit=before+90.
            while not worker.batch_drained:
                rows=worker.poll()
                if rows:received+=rows
                events+=worker.drain_telemetry()
                if time.perf_counter()>limit:raise TimeoutError('owned context operator did not drain')
                time.sleep(.001)
            endtime=time.perf_counter();assert len(received)==1;row=received[0]
            expected_P,expected_text=render(job,row['token_ids'])
            assert expected_P==row['state_tokens'] and expected_text==row['text']
            audit=row['model_input_audit'];assert audit['actual_interval']==[start,end]
            if audit['prompt_ids']:assert audit['actual_first_decoder_ids'][:len(audit['prompt_ids'])]==audit['prompt_ids']
            if a.whisper_context_policy=='reserve-generation-tail-v1':
                assert audit['actual_first_decoder_ids']==audit['conditioning_plan']['expected_initial_decoder_ids']
                assert len(audit['actual_first_decoder_ids'])+256<=conditioning['max_target_positions']
            record=dict(id=jid,sid=sid,phase=phase,window=index,job=job,result=row,physical_telemetry=events,submit_perf=before,drained_perf=endtime,paid_owner_lease_seconds=endtime-before,raw_selected_segment=tok.decode(row['token_ids'],skip_special_tokens=True,clean_up_tokenization_spaces=False).strip(),scope='actual trusted model operator; no production state installation')
            calls.append(record);put(f'call-{len(calls):04}.json',record);return record
        def trajectory(case,phase,start,P,segments,expected=None):
            sid=case['session_id'];rows=[];P=list(P);segments=list(segments)
            for window in range(start,9):
                r=call(sid,phase,window,window*160000,(window+1)*160000,P,window)
                P=list(r['result']['state_tokens']);segments.append(r['raw_selected_segment']);rows.append(r)
            repeated=None
            if expected is not None:
                repeated=len(rows)==len(expected) and all(r['result']['token_ids']==q['result']['token_ids'] and r['result']['state_tokens']==q['result']['state_tokens'] and r['result']['text']==q['result']['text'] and r['result']['model_input_audit']==q['result']['model_input_audit'] for r,q in zip(rows,expected))
            text=' '.join(segments).strip();ref=segment_words(inputs[sid]['reference']);wer=100*edit_distance(ref,segment_words(text))/len(ref)
            if phase in ['full_reference','stored_checkpoint','missing_prefix_rebuild']:
                assert segment_words(text)==segment_words(rows[-1]['result']['text'])
            return dict(phase=phase,calls=[r['id'] for r in rows],final_conditioning_tokens=P,evaluation_transcript=text,WER=wer,reference_words=len(ref),repeat_equal=repeated,capped_generations=sum(not r['result']['terminated_by_eos'] for r in rows),paid_lease_seconds=sum(r['paid_owner_lease_seconds'] for r in rows),segment_log_scope='chronological selected new-segment evaluation only; transformed histories are not v7 Canonical text'),rows
        for case in cases:
            sid=case['session_id'];cut=case['cut_window'];full,refrows=trajectory(case,'full_reference',0,[],[])
            checkpoint=refrows[cut-1]['result']['state_tokens'];prefix_segments=[r['raw_selected_segment'] for r in refrows[:cut]]
            acquisition=sum(r['paid_owner_lease_seconds'] for r in refrows[:cut])
            restored,_=trajectory(case,'stored_checkpoint',cut,checkpoint,prefix_segments,refrows[cut:])
            rebuilt,_=trajectory(case,'missing_prefix_rebuild',0,[],[],refrows)
            cleared,_=trajectory(case,'clear_at_cut',cut,[],prefix_segments)
            lower=max(0,cut-2)*160000
            capsule=call(sid,'past_audio_reanchor',cut,lower,cut*160000,[],0)
            anchored,_=trajectory(case,'after_reanchor',cut,capsule['result']['state_tokens'],prefix_segments)
            anchored['calls'].insert(0,capsule['id']);anchored['paid_lease_seconds']+=capsule['paid_owner_lease_seconds']
            for suffix_control in [restored,cleared,anchored]:
                charge_missing_prefix(suffix_control,acquisition)
            outcome=dict(case=case,controls=[full,restored,rebuilt,cleared,anchored],trusted_anchor_acquisition_paid_once_physical_seconds=acquisition,restore_in_existing_exact_checkpoint_case_marginal_seconds=restored['paid_lease_seconds'],prefix_cost_scope='all suffix controls reuse the actually paid reference prefix; if that prefix did not exist, charge it to every control, not just restore; no partial-audio capsule discharges missing accepted history',original_reference_WER=inputs[sid]['historical_canonical_wer'],original_EFSC_WER=inputs[sid]['historical_efsc_wer'],legacy_WER_comparability='different precision/adapter/layout/budget; listed as historical context, not a matched delta')
            outcomes.append(outcome);put(f'CASE-{sid}.json',outcome)
            if restored['repeat_equal'] is not True or rebuilt['repeat_equal'] is not True:
                put('GATE.json',dict(gate='NO_GO_NATIVE_REPEAT_INPUT_OR_OUTPUT_DIFFERENCE',case=sid,context_mechanism_formal_matrix=False));break
        energy=[]
        for r in calls:energy.append(dict(id=r['id'],both_GPU_joules=power.joules(r['submit_perf'],r['drained_perf'])))
        put('CALL_ENERGY.json',energy)
        put('SUMMARY.json',dict(status='PAID_FEASIBILITY_RECORDED',cases=outcomes,actual_neural_model_calls=len(calls),application_installs=0,new_context_algorithm=False,formal_matrix_started=False,scope='strong existing context controls with real prefix acquisition; no replica claim for legacy16-rowFP16 and no deployed throughput claim'))
        if not (a.out/'GATE.json').exists():put('GATE.json',dict(gate='REQUIRES_INDEPENDENT_QUALITY_COST_AND_NOVELTY_DECISION',complete_cases=len(outcomes),source_commit=own['code_commit'],new_mechanism_promoted=False))
    except BaseException:
        put('STOP.json',dict(completed_cases=outcomes,actual_completed_calls=len(calls),error=traceback.format_exc()));raise
    finally:
        if worker is not None:worker.close()
        if power is not None:power.close()


if __name__=='__main__':main()
