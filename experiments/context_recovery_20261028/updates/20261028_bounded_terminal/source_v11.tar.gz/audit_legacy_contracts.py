"""Case-level recorded R7/R8/R9 audit; no GPU, no retrospective provenance repair."""
from pathlib import Path
import argparse,csv,hashlib,json,platform,re,subprocess,sys,time
WORDS=re.compile(r"[a-z0-9]+(?:'[a-z0-9]+)?")


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def words(s):return WORDS.findall(s.lower())


def distance(a,b):
    last=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1):row.append(min(row[-1]+1,last[j]+1,last[j-1]+(x!=y)))
        last=row
    return last[-1]


def catastrophic(wer,reference):
    d=wer-reference;return d>10. or (wer>2*max(reference,1.) and d>5.)


def bound_quality_reference(value,base_sha,traced_sha,core_equal):
    return value==base_sha or (core_equal and value==traced_sha)


def main():
    p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
    assert not a.out.exists();a.out.mkdir(parents=True);records=[]
    own=json.loads(a.source_manifest.read_text())
    for r in own['files']:assert sha(Path(__file__).parent/r['path'])==r['sha256']
    baseline='4af44aac707ba84119ea13f05f6a9130c869dec4'
    def load(name):
        b=(a.archive/name).read_bytes();old=subprocess.check_output(['git','-C',str(a.archive),'show',baseline+':'+name]);assert b==old,name
        records.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));return json.loads(b)
    r7path='results/r7_efsc/whisper_base_quality/paired-128.json';r7=load(r7path);r7sha=sha(a.archive/r7path)
    traced=load('results/r7_efsc/whisper_base_quality/paired-128-traced.json')
    manifest=load('experiments/input_freeze_20261027/r7_identity/remote_files/datasets/revtrace/librispeech/whisper-w-quality.json')
    byid={r['utterance_id']:r for r in manifest['records']};trace={r['session_id']:r for r in traced['sessions']}
    environment=dict(python=sys.version,platform=platform.platform(),word_normalization_regex=WORDS.pattern)
    (a.out/'ENVIRONMENT.json').write_text(json.dumps(environment,indent=2)+'\n')
    freeze=dict(experiment_id='REVTRACE-R7-R8-R9-PER-ANOMALY-CONTRACT-AUDIT-20261028',source_commit=own['code_commit'],source_manifest_sha256=sha(a.source_manifest),archive_commit=baseline,original_R7_quality_sha256=r7sha,environment_sha256=sha(a.out/'ENVIRONMENT.json'),raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'RESULT.json'),gate_decision_location=str(a.out/'GATE.json'),GPU_calls=0)
    (a.out/'FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')
    roots=[];allcase=[]
    for r in r7['sessions']:
        t=trace[r['session_id']]
        for k in ['utterance_ids','canonical_text','efsc_text','feedback_off_text','canonical_wer','efsc_wer','catastrophic_outlier']:assert r[k]==t[k]
        reference=' '.join(byid[x]['text'] for x in r['utterance_ids']);ref=words(reference);assert len(ref)==r['reference_words']
        values={k:100*distance(ref,words(r[k+'_text']))/len(ref) for k in ['canonical','efsc','feedback_off']}
        for k,v in values.items():assert abs(v-r[k+'_wer'])<1e-9
        flag=catastrophic(values['efsc'],values['canonical']);assert flag==r['catastrophic_outlier']
        row=dict(session_id=r['session_id'],utterance_ids=r['utterance_ids'],reference_words=len(ref),recorded_WER=values,catastrophic=flag,duration_seconds=r7['config']['duration_seconds'],legacy_contract='FP16 raw-token-history, margin FAST_COMMIT,10s windows,96token budget; not current exactFP32')
        allcase.append(row)
        if flag:
            details=t['efsc_trace'];low=[e for e in details if e['terminated_by_eos'] and len(e['candidate_token_ids'])<=10]
            row.update(prompt_empty_windows=[e['window_index'] for e in details if e['prompt_tokens_for_proposal']==0],hold_windows=[e['window_index'] for e in details if e['decision_action']=='provisional-hold'],reset_before_windows=[e['window_index'] for e in details if e.get('prepare_action')=='safe-reset'],low_yield_EOS_windows=[dict(window=e['window_index'],content_tokens=len(e['candidate_token_ids']),prompt_tokens=e['prompt_tokens_for_proposal'],margin=e['minimum_margin']) for e in low],causal_status='recorded association; same-input controlled neural test required for per-case attribution',legacy_sequence_scope='candidate content-token records and Stop flag do not substitute for current full selected-Z/actual-input evidence',r8_views=[],r9_same_complete_input_matches=[])
            roots.append(row)
    assert len(roots)==11
    # R8 view rows are joined only when their entire source-quality artifact is bound.
    for name in ['vacc-10.json','vacc-20.json','vacc-30.json','snapshot-delta.json']:
        path='results/r8_csdr/'+name
        if not (a.archive/path).exists():continue
        view=load(path)
        # The traced artifact adds execution observations to the same complete
        #128quality rows. Every relevant core field has been compared above.
        traced_sha=sha(a.archive/'results/r7_efsc/whisper_base_quality/paired-128-traced.json')
        bound=bound_quality_reference(view.get('source_quality_sha256'),r7sha,traced_sha,True)
        for row in view.get('rows',[]):
            selected=next((r for r in roots if r['session_id']==row['session_id']),None)
            if selected is None:continue
            selected['r8_views'].append(dict(path=path,source_quality_byte_bound=bound,source_quality_sha256=view.get('source_quality_sha256'),traced_core_equality_validated=True,WER=row.get('wer'),catastrophic=row.get('catastrophic_outlier'),capsule_seconds=row.get('capsule_seconds'),proposal_seconds=row.get('proposal_seconds'),anchor_cost_scope='Snapshot+Delta reference anchor acquisition excluded from capsule_seconds; charge it in deployment' if name=='snapshot-delta.json' else 'recorded component view cost, not a full serving energy claim'))
    r9info=[]
    for name in ['semantic_margin15_validation/base-development-semantic-escalation.json','final_holdout3/base-semantic-final3-confirmation.json']:
        path='results/r9_dgft/'+name;r9=load(path);matches=0
        lookup={tuple(r['utterance_ids']):r for r in r9['sessions']}
        for root in roots:
            r=lookup.get(tuple(root['utterance_ids']))
            if r is not None:
                root['r9_same_complete_input_matches'].append(dict(path=path,WER=r['wer'],reference_WER=r['canonical_wer'],duration=r9['config']['duration_seconds']));matches+=1
        r9info.append(dict(path=path,sessions=len(r9['sessions']),duration_seconds=r9['config']['duration_seconds'],exact_ordered_R7_root_input_matches=matches,reported_catastrophic=r9['metrics']['catastrophic_outliers'],reference_scope='own source-quality baseline; not assumed equal to R7 singleton reference',speed_scope='quality artifact projected-two-GPU component estimate; separate online service has its own contract'))
    result=dict(status='PASS_RECORDED_PER_CASE_AND_CROSS_CONTRACT_RECOUNT',R7_sessions=len(allcase),roots=roots,R9_cohorts=r9info,source_records=records,original_execution_identity='UNKNOWN where original loaded-source/env/weight bindings absent',causal_limit='No historical association is promoted to a new controlled neural result; no cross-duration/cohort quality transfer',GPU_calls=0)
    (a.out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    with (a.out/'ANOMALY_MATRIX.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['session_id','reference_words','canonical_WER','EFSC_WER','off_WER','empty_windows','low_yield_EOS_windows','R8_byte_bound_views','R9_same_complete_inputs','causal_status']);w.writeheader()
        for r in roots:w.writerow(dict(session_id=r['session_id'],reference_words=r['reference_words'],canonical_WER=r['recorded_WER']['canonical'],EFSC_WER=r['recorded_WER']['efsc'],off_WER=r['recorded_WER']['feedback_off'],empty_windows=json.dumps(r['prompt_empty_windows']),low_yield_EOS_windows=json.dumps(r['low_yield_EOS_windows']),R8_byte_bound_views=sum(x['source_quality_byte_bound'] for x in r['r8_views']),R9_same_complete_inputs=len(r['r9_same_complete_input_matches']),causal_status=r['causal_status']))
    (a.out/'GATE.json').write_text(json.dumps(dict(gate='PASS_RECORDED_AUDIT_NOT_GPU_CAUSALITY',R7_roots=11,source_commit=own['code_commit'],GPU_calls=0),indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],roots=11,R9_cohorts=r9info)))


if __name__=='__main__':main()
