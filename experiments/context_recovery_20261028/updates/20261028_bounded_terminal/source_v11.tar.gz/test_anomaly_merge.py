from merge_anomaly_evidence import cap_counts


def test_inherited_caps_and_capsule_caps_have_different_transcript_roles():
    case=dict(case=dict(session_id=0,cut_window=1),controls=[dict(phase='full_reference',calls=['p','f']),dict(phase='after_reanchor',calls=['capsule','s'])])
    checked={x:dict(capped=True) for x in ['p','f','capsule','s']}
    rows=cap_counts(case,checked)
    assert rows[0]['evaluated_transcript_cap_events']==2
    assert rows[1]['paid_call_cap_events']==2
    assert rows[1]['inherited_prefix_cap_events']==1
    assert rows[1]['reanchor_conditioning_only_cap_events']==1
    assert rows[1]['evaluated_transcript_cap_events']==2
