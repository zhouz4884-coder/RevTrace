"""Descriptive full-denominator decision from independently audited paid data."""
from pathlib import Path
import argparse,hashlib,json,platform,statistics,sys


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def aggregate(rows):
    return dict(cases=len(rows),errors=sum(r['errors'] for r in rows),reference_words=sum(r['reference_words'] for r in rows),
        pooled_WER=100*sum(r['errors'] for r in rows)/sum(r['reference_words'] for r in rows),
        median_WER=statistics.median(r['WER'] for r in rows),caps=sum(r['capped_generations'] for r in rows),
        paid_lease_seconds=sum(r['paid_lease_seconds'] for r in rows),
        paid_lease_if_prefix_missing_seconds=sum(r['paid_lease_if_prefix_missing_seconds'] for r in rows),
        GPU_joules=sum(r['GPU_joules'] for r in rows),GPU_joules_if_prefix_missing=sum(r['GPU_joules_if_prefix_missing'] for r in rows))


def main():
    p=argparse.ArgumentParser();p.add_argument('--audit',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
    source=json.loads(a.source_manifest.read_text())
    for r in source['files']:assert sha(Path(__file__).parent/r['path'])==r['sha256']
    assert not a.out.exists();a.out.mkdir(parents=True)
    def put(n,x):
        with (a.out/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
    result=json.loads((a.audit/'RESULT.json').read_text());assert result['status']=='PASS_INDEPENDENT_ACTUAL_INPUT_RENDER_QUALITY_COST_AUDIT'
    env=dict(python=sys.version,platform=platform.platform());put('ENVIRONMENT.json',env)
    put('FREEZE.json',dict(experiment_id='REVTRACE-CONTEXT-PAID-DECISION-20261028',source_commit=source['code_commit'],source_manifest_sha256=sha(a.source_manifest),audit_result_sha256=sha(a.audit/'RESULT.json'),environment_sha256=sha(a.out/'ENVIRONMENT.json'),raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'RESULT.json'),gate_decision_location=str(a.out/'GATE.json'),analysis_scope='descriptive all14; leave-one-out sensitivity is diagnosis, not a replacement estimate',GPU_calls=0))
    rows=result['rows'];methods=sorted({r['control'] for r in rows});lookup={(r['session_id'],r['control']):r for r in rows}
    stats={m:aggregate([r for r in rows if r['control']==m]) for m in methods}
    # Report every leave-one-out point; never choose one to become the headline.
    ids=sorted({r['session_id'] for r in rows})
    sensitivity={str(s):{m:aggregate([r for r in rows if r['control']==m and r['session_id']!=s])['pooled_WER'] for m in methods} for s in ids}
    paired={}
    for m in methods:
        ds=[lookup[s,m]['WER']-lookup[s,'full_reference']['WER'] for s in ids]
        paired[m]=dict(improved=sum(x<0 for x in ds),worsened=sum(x>0 for x in ds),equal=sum(x==0 for x in ds),median_delta_WER_pp=statistics.median(ds),deltas={str(s):d for s,d in zip(ids,ds)})
    decision=dict(gate='NO_GO_NEW_CONTEXT_ALGORITHM_OR_FORMAL_MATRIX_FROM_THIS_STUDY',
        actual_paid_calls=result['actual_neural_calls'],cases=len(ids),unchanged_checkpoint_and_rebuild=True,
        reasons=['A valid saved current parent reproduces its selected output; full missing-prefix rebuild pays approximately the full reference work.',
                 'Clear/reanchor are already implemented R8-class controls, not a new mechanism; their changed conditioning does not preserve the original Canonical selection contract.',
                 'The largest pooled WER improvement is driven by one repetitive reference trajectory; full per-case and leave-one-out outcomes include regressions.',
                 'The conventional capacity repair removes a concrete invocation error but is not exclusive RevTrace scheduling or a new recovery algorithm.'],
        historical_causes='recorded cross-contract associations remain distinct; current FP32/batch1/256 outputs cannot prove causes in the original FP16/batch16/96 run with UNKNOWN original loaded-source binding',
        input_observation_scope='actual decoder first-input hook and generate-boundary feature hashes reconstructed; attention-mask tensor not separately captured, no kernel-input attestation claim',
        untouched_holdout_calls=0,new_recovery_mechanism_implemented=False,paper_modified=False)
    put('RESULT.json',dict(aggregates=stats,paired_quality=paired,leave_one_out_pooled_WER=sensitivity,decision=decision,scope='fourteen historically selected diagnostic sources, not natural prevalence, independent holdout success, RTO, throughput or significance'))
    put('GATE.json',decision)
    print(json.dumps(dict(aggregates=stats,paired_quality=paired,decision=decision),indent=2))


if __name__=='__main__':main()
