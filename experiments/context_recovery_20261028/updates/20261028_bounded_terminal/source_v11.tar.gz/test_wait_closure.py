import hashlib,json,struct
import pytest
from audit_wait_closure import frames,action_counts


def test_archive_frame_bytes_reject_corruption():
    b=json.dumps(dict(sequence=0,previous_sha256='')).encode();raw=struct.pack('>I',len(b))+b+hashlib.sha256(b).digest()
    assert frames(raw)[0]['sequence']==0
    with pytest.raises(AssertionError):frames(raw[:-1])
    with pytest.raises(AssertionError):frames(raw[:-1]+b'x')


def test_inactive_decisions_are_not_waiting_opportunities():
    events=[dict(event='dispatch-wait-decision',session_id=0,window=1,decision='dispatch'),dict(event='dispatch-wait-input-outcome',session_id=0,window=1,declared_P_changed=True,root_frontier_changed=True)]
    assert action_counts(events)['actual_wait_targets']==0
    assert action_counts(events)['changed_declared_P']==0
