from native_prompt_probe import clarified


def test_clarification_does_not_rewrite_actual_user_source_or_supply_answers():
    old=[dict(role='system',content='Choose a legal step.'),dict(role='user',content='{"source":{"a":[]},"prior_memory":{}}')]
    for family in ['runbook','resource_plan']:
        new=clarified(old,family)
        assert new[-1]==old[-1] and new[0]['content'].startswith(old[0]['content'])
        assert old[0]['content']=='Choose a legal step.'
        assert 'inspect' not in new[0]['content'] and 'gamma' not in new[0]['content']
