"""Read-only archive, normalized WAL and wait-action recount; no serving code."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,platform,struct,sys,tarfile


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def frames(data):
    pos=0;previous='';out=[]
    while pos<len(data):
        assert len(data)-pos>=4
        n=struct.unpack_from('>I',data,pos)[0];end=pos+4+n+32
        assert 0<n<=32*1024*1024 and end<=len(data)
        b=data[pos+4:pos+4+n];d=hashlib.sha256(b).digest();assert d==data[pos+4+n:end]
        r=json.loads(b);assert r['sequence']==len(out) and r['previous_sha256']==previous
        out.append(r);previous=d.hex();pos=end
    return out


def action_counts(events):
    assert events and all(isinstance(r.get('kind'),str) for r in events),'runtime event schema missing kind; do not report zero actions'
    keys={(r['session_id'],r['window']) for r in events if r['kind']=='dispatch-wait-decision' and r['decision']=='wait'}
    outcomes=[r for r in events if r['kind']=='dispatch-wait-input-outcome' and (r['session_id'],r['window']) in keys]
    return dict(actual_wait_targets=len(keys),waits_with_dispatched_input=len(outcomes),
        changed_declared_P=sum(r['declared_P_changed'] is True for r in outcomes),
        changed_root=sum(r['root_frontier_changed'] is True for r in outcomes),
        releases=dict(Counter(r['reason'] for r in events if r['kind']=='dispatch-wait-release')))


def main():
    p=argparse.ArgumentParser();p.add_argument('--cut',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
    source=json.loads(a.source_manifest.read_text())
    for f in source['files']:assert sha(Path(__file__).parent/f['path'])==f['sha256']
    assert not a.out.exists();a.out.mkdir(parents=True)
    def put(n,x):
        with (a.out/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
    index=json.loads((a.cut/'RAW_INDEX.json').read_text());archive=a.cut/'COMPLETED_RAW_RECORDS.tar.gz';assert sha(archive)==index['archive_sha256']
    stage=index['stages'][0];env=dict(python=sys.version,platform=platform.platform());put('ENVIRONMENT.json',env)
    put('FREEZE.json',dict(experiment_id='REVTRACE-WAIT-CLOSURE-INDEPENDENT-RECOUNT-20261028',source_commit=source['code_commit'],source_manifest_sha256=sha(a.source_manifest),archive_sha256=sha(archive),raw_index_sha256=sha(a.cut/'RAW_INDEX.json'),environment_sha256=sha(a.out/'ENVIRONMENT.json'),raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'RESULT.json'),gate_decision_location=str(a.out/'GATE.json'),GPU_calls=0))
    with tarfile.open(archive,'r:gz') as tar:
        expected={r['path']:r for r in index['files']};seen=set()
        for member in tar:
            assert member.isfile() and member.name in expected and member.name not in seen
            b=tar.extractfile(member).read();r=expected[member.name];assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];seen.add(member.name)
        assert seen==set(expected)
        def read(name):return tar.extractfile(stage+'/'+name).read()
        summary=json.loads(read('SUMMARY.json'));assert summary['status']=='COMPLETE_DEVELOPMENT_PILOT' and summary['expected']==len(summary['completed'])==len(summary['rows'])==6
        rows=[];reference=None
        for cell,r in zip(summary['completed'],summary['rows']):
            records=frames(read(cell+'/canonical.wal'));head={int(k):v['checkpoint_id'] for k,v in records[0]['states'].items()};F={int(k):v['audio_frontier_window'] for k,v in records[0]['states'].items()};history=[]
            for v in records[1:]:
                assert v['kind']=='commit';sid=v['session_id'];d=v['state_delta'];e=v['event']
                assert d['kind']=='canonical-segment' and v['parent_checkpoint_id']==head[sid]
                assert d['audio_start_sample']==F[sid] and d['audio_end_sample']>F[sid]
                assert hashlib.sha256(e['committed_text'].encode()).hexdigest()==e['text_binding']['text_sha256']
                inputs=e['text_binding']['render_inputs'];assert inputs['token_ids']==d['segment_tokens'] and inputs['state_tokens']==d['next_prompt_tokens']
                history.append([sid,d['audio_start_sample'],d['audio_end_sample'],v['parent_checkpoint_id'],d['segment_tokens'],d['next_prompt_tokens'],e['committed_text']]);head[sid]+=1;F[sid]=d['audio_end_sample']
            history.sort(key=lambda v:(v[0],v[1]));equal=True if reference is None else history==reference
            if reference is None:reference=history
            events=[json.loads(line) for line in read(cell+'/attempt0/events.jsonl').splitlines() if line]
            counts=action_counts(events)
            rows.append(dict(policy=r['policy'],commits=len(history),normalized_history_equal_to_immediate=equal,history_sha256=hashlib.sha256(json.dumps(history,sort_keys=True,separators=(',',':')).encode()).hexdigest(),actions=counts,goodput=r['all_offered_audio_goodput_2_8'],display_P99=r['display_P99'],commit_P99=r['commit_view_P99'],GPU_J_per_offered_audio_second=r['GPU_J_per_offered_audio_second'],whole_dual_P99_pass=r['whole_run_dual_P99_pass'],WER_errors=r['WER_errors'],WER_reference_words=r['WER_reference_words'],unresolved_wait_feedback=r['dispatch_wait_profile']['unresolved_wait_feedback']))
    put('RESULT.json',dict(status='PASS_ARCHIVE_WAL_WAIT_ACTION_RECOUNT',rows=rows,raw_files_verified=len(seen),GPU_calls=0,scope='Single development repeat, not independent-source performance confirmation; existing separate Consumer observer supplied service metrics; this audit independently checks recorded WAL and actual wait actions, not neural selection truth'))
    put('GATE.json',dict(gate='DESCRIPTIVE_RECOUNT_COMPLETE_NOT_PERFORMANCE_SUPERIORITY',source_commit=source['code_commit'],cases=6,GPU_calls=0));print(json.dumps(dict(rows=rows),indent=2))


if __name__=='__main__':main()
