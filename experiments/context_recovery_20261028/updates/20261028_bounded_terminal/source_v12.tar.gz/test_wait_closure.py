import hashlib,json,struct
import pytest
from audit_wait_closure import frames,action_counts


def test_archive_frame_bytes_reject_corruption():
    b=json.dumps(dict(sequence=0,previous_sha256='')).encode();raw=struct.pack('>I',len(b))+b+hashlib.sha256(b).digest()
    assert frames(raw)[0]['sequence']==0
    with pytest.raises(AssertionError):frames(raw[:-1])
    with pytest.raises(AssertionError):frames(raw[:-1]+b'x')


def test_inactive_decisions_are_not_waiting_opportunities():
    events=[dict(kind='dispatch-wait-decision',session_id=0,window=1,decision='dispatch'),dict(kind='dispatch-wait-input-outcome',session_id=0,window=1,declared_P_changed=True,root_frontier_changed=True)]
    assert action_counts(events)['actual_wait_targets']==0
    assert action_counts(events)['changed_declared_P']==0


def test_real_kind_schema_counts_active_actions_and_rejects_missing_schema():
    rows=[dict(kind='dispatch-wait-decision',session_id=1,window=2,decision='wait'),dict(kind='dispatch-wait-input-outcome',session_id=1,window=2,declared_P_changed=True,root_frontier_changed=True),dict(kind='dispatch-wait-release',reason='canonical-update')]
    assert action_counts(rows)==dict(actual_wait_targets=1,waits_with_dispatched_input=1,changed_declared_P=1,changed_root=1,releases={'canonical-update':1})
    with pytest.raises(AssertionError):action_counts([dict(event='dispatch-wait-decision')])
