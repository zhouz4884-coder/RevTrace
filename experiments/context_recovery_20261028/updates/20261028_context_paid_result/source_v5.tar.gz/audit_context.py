"""Independent recorded-input/quality/cost audit. No generation or admission."""
from pathlib import Path
import argparse,csv,hashlib,importlib.metadata,json,platform,re,sys,traceback


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def words(s):return re.findall(r"[a-z0-9]+(?:'[a-z0-9]+)?",s.lower())


def distance(a,b):
    last=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1):row.append(min(row[-1]+1,last[j]+1,last[j-1]+(x!=y)))
        last=row
    return last[-1]


def joules(rows,start,end):
    assert rows and rows[0]['observed_perf']<=start<=end<=rows[-1]['observed_perf']
    total=0.
    for a,b in zip(rows,rows[1:]):
        lo=max(start,a['observed_perf']);hi=min(end,b['observed_perf'])
        if hi<=lo:continue
        dt=b['observed_perf']-a['observed_perf'];pa=sum(x['watts'] for x in a['GPUs'].values());pb=sum(x['watts'] for x in b['GPUs'].values())
        total+=(pa+(pb-pa)*(lo-a['observed_perf'])/dt+pa+(pb-pa)*(hi-a['observed_perf'])/dt)/2*(hi-lo)
    return total


def conditioning(raw,capacity,marker,initial):
    assert capacity>=2
    if raw:assert raw[0]==marker
    return (raw if len(raw)<=capacity else [raw[0]]+raw[-(capacity-1):])+initial


def main():
    p=argparse.ArgumentParser();p.add_argument('--study',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--source-manifest',type=Path,required=True);p.add_argument('--model',type=Path,required=True);a=p.parse_args()
    assert not a.out.exists();a.out.mkdir(parents=True)
    def put(n,x):
        with (a.out/n).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
    source=json.loads(a.source_manifest.read_text())
    for r in source['files']:assert sha(Path(__file__).parent/r['path'])==r['sha256']
    env=dict(python=sys.version,platform=platform.platform(),packages={n:importlib.metadata.version(n) for n in ['transformers','numpy','soundfile']})
    put('ENVIRONMENT.json',env)
    put('FREEZE.json',dict(experiment_id='REVTRACE-INDEPENDENT-PAID-CONTEXT-AUDIT-20261028',source_commit=source['code_commit'],source_manifest_sha256=sha(a.source_manifest),study_freeze_sha256=sha(a.study/'FREEZE.json'),environment_sha256=sha(a.out/'ENVIRONMENT.json'),raw_result_location=str(a.out),aggregate_summary_location=str(a.out/'RESULT.json'),gate_decision_location=str(a.out/'GATE.json'),GPU_calls=0,scope='recorded actual inputs and operator costs only; no model truth, admission or serving proof'))
    try:
        import numpy as np,soundfile as sf
        from transformers import WhisperProcessor
        assert not (a.study/'STOP.json').exists()
        summary=json.loads((a.study/'SUMMARY.json').read_text());freeze=json.loads((a.study/'FREEZE.json').read_text())
        assert len(summary['cases'])==len(freeze['cases'])==14
        for name,value in json.loads((a.study/'MODEL_ASSETS.json').read_text()).items():assert sha(a.model/name)==value
        proc=WhisperProcessor.from_pretrained(a.model,local_files_only=True);tok=proc.tokenizer
        gen=json.loads((a.model/'generation_config.json').read_text());cfg=json.loads((a.model/'config.json').read_text())
        assert gen['is_multilingual'] is False and gen['forced_decoder_ids']==[[1,gen['no_timestamps_token_id']]]
        init=[gen['decoder_start_token_id'],gen['no_timestamps_token_id']];eos=tok.eos_token_id;capacity=cfg['max_target_positions']-len(init)-256
        audio={};reference={}
        for r in json.loads((a.study/'manifest.json').read_text())['sessions']:
            x,rate=sf.read(r['path'],dtype='float32');assert rate==16000 and hashlib.sha256(x.tobytes()).hexdigest()==r['audio_sha256']
            audio[r['source_id']]=x;reference[r['source_id']]=r['reference']
        power=[json.loads(s) for s in (a.study/'power.jsonl').read_text().splitlines()]
        energy={r['id']:r['both_GPU_joules'] for r in json.loads((a.study/'CALL_ENERGY.json').read_text())}
        calls={};features={};checked=[]
        for path in sorted(a.study.glob('call-*.json')):
            r=json.loads(path.read_text());j=r['job'];v=r['result'];m=v['model_input_audit'];Z=v['token_ids'];P=j['prompt_tokens']
            hist=tok.decode(P,skip_special_tokens=True,clean_up_tokenization_spaces=False)
            raw=[int(t) for t in proc.get_prompt_ids(hist,return_tensors='np')] if hist else []
            actual=conditioning(raw,capacity,gen['prev_sot_token_id'],init)
            assert m['history']==hist and m['actual_first_decoder_ids']==actual
            assert m['conditioning_plan']['raw_prompt_ids']==raw and m['prompt_ids']==actual[:-len(init)]
            assert len(actual)+256<=cfg['max_target_positions'] and 0<len(Z)<=256
            positions=[i for i,t in enumerate(Z) if t==eos]
            assert (positions==[len(Z)-1]) if positions else len(Z)==256
            assert v['terminated_by_eos']==bool(positions) and v['hit_token_limit']==(not positions and len(Z)==256)
            assert m['full_decoder_sequence']==actual+Z
            seg=tok.decode(Z,skip_special_tokens=True,clean_up_tokenization_spaces=False).strip()
            text=(hist+' '+seg).strip() if hist else seg
            assert v['text']==text and v['state_tokens']==tok.encode(text,add_special_tokens=False)
            assert r['raw_selected_segment']==seg
            start,end=j['audio_start_sample'],j['audio_end_sample'];x=audio[j['source_id']]
            assert start==j['chunk_id']*32000 and 0<=start<end<=len(x)
            assert m['actual_interval']==[start,end]
            assert hashlib.sha256(x[:end].tobytes()).hexdigest()==m['waveform_sha256']==j['prefix_audio_sha256']
            key=(j['source_id'],start,end)
            if key not in features:
                f=proc(x[start:end],sampling_rate=16000,return_tensors='np',return_attention_mask=True).input_features
                features[key]=hashlib.sha256(f.tobytes()).hexdigest()
            assert m['input_features_sha256']==m['actual_gpu_features_sha256']==features[key]
            E=joules(power,r['submit_perf'],r['drained_perf']);assert abs(E-energy[r['id']])<1e-5
            assert abs(r['paid_owner_lease_seconds']-(r['drained_perf']-r['submit_perf']))<1e-9
            assert r['submit_perf']<=v['model_started_perf']<=v['model_completed_perf']<=r['drained_perf']
            calls[r['id']]=r;checked.append(dict(id=r['id'],sid=r['sid'],phase=r['phase'],window=r['window'],capped=not positions,trimmed_history_tokens=len(raw)-(len(actual)-len(init)),paid_lease_seconds=r['paid_owner_lease_seconds'],actual_model_seconds=v['model_completed_perf']-v['model_started_perf'],GPU_joules=E))
        rows=[]
        for case in summary['cases']:
            sid=case['case']['session_id'];cut=case['case']['cut_window'];controls=case['controls'];full=controls[0]
            assert controls[1]['repeat_equal'] is True and controls[2]['repeat_equal'] is True
            fullcalls=[calls[x] for x in full['calls']]
            for c in controls:
                rs=[calls[x] for x in c['calls']];assert rs
                charge=sum(r['paid_owner_lease_seconds'] for r in rs)
                assert abs(c['paid_lease_seconds']-charge)<1e-7
                ref=words(reference[f'legacy-{sid}']);error=distance(ref,words(c['evaluation_transcript']))
                assert c['reference_words']==len(ref) and abs(c['WER']-100*error/len(ref))<1e-9
                if c['phase']=='stored_checkpoint':
                    assert rs[0]['job']['prompt_tokens']==fullcalls[cut-1]['result']['state_tokens']
                    assert [r['result']['token_ids'] for r in rs]==[r['result']['token_ids'] for r in fullcalls[cut:]]
                if c['phase']=='missing_prefix_rebuild':
                    assert [r['result']['token_ids'] for r in rs]==[r['result']['token_ids'] for r in fullcalls]
                missing=c.get('model_work_with_missing_prefix_seconds',charge)
                if 'if_no_preexisting_trusted_prefix_add_acquisition_seconds' in c:
                    acquire=sum(r['paid_owner_lease_seconds'] for r in fullcalls[:cut])
                    assert abs(missing-(charge+acquire))<1e-7
                rows.append(dict(session_id=sid,is_legacy_root=case['case']['is_legacy_root'],control=c['phase'],WER=c['WER'],errors=error,reference_words=len(ref),WER_delta_from_current_native_reference=c['WER']-full['WER'],capped_generations=c['capped_generations'],paid_lease_seconds=charge,paid_lease_if_prefix_missing_seconds=missing,GPU_joules=sum(energy[r['id']] for r in rs),production_installs=0,scope='operator, not deployed service; transformed evaluation log is not Canonical text'))
        assert len(calls)==summary['actual_neural_model_calls'] and len(rows)==70
        put('RESULT.json',dict(status='PASS_INDEPENDENT_ACTUAL_INPUT_RENDER_QUALITY_COST_AUDIT',cases=14,legacy_roots=11,actual_neural_calls=len(calls),rows=rows,checked_calls=checked,model_features_reconstructed=len(features),application_installs=0,GPU_audit_calls=0,novel_recovery_algorithm=False,scope='strict selected provenance is not transcript correctness; conventional contexts can produce different legal histories; no legacy matched-performance claim'))
        with (a.out/'QUALITY_COST.csv').open('x',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        put('GATE.json',dict(gate='PASS_RECORDED_INPUT_QUALITY_COST_NOT_NOVELTY',source_commit=source['code_commit'],cases=14,rows=70,GPU_calls=0))
    except BaseException:
        put('STOP.json',dict(error=traceback.format_exc(),GPU_calls=0));raise


if __name__=='__main__':main()
