import pytest
from audit_context import conditioning,joules,distance,words


def test_capacity_view_not_canonical_rewrite():
    raw=[9,1,2,3,4]
    assert conditioning(raw,3,9,[7,8])==[9,3,4,7,8]
    assert raw==[9,1,2,3,4]
    with pytest.raises(AssertionError):conditioning([0,1],3,9,[7,8])


def test_actual_both_board_energy_interpolation():
    rows=[dict(observed_perf=0.,GPUs={'0':dict(watts=10.),'1':dict(watts=20.)}),dict(observed_perf=2.,GPUs={'0':dict(watts=20.),'1':dict(watts=30.)})]
    assert joules(rows,.5,1.5)==40.
    with pytest.raises(AssertionError):joules(rows,-1.,1.)


def test_quality_denominators_are_original_reference_words():
    assert words("A can't.")==['a',"can't"]
    assert distance(['a','b'],['a','c','d'])==2
