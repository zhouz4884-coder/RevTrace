"""Bounded FP32 certification/cost probe. No online selector or KV fallback."""
import argparse,copy,hashlib,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts/v100')]
from revtrace.live_qwen import fingerprint
from tc_live_worker import GPUExecutor
from run_v100_matrix import PowerSampler

def save(p,x):
    t=p.with_suffix(p.suffix+'.partial');t.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');t.replace(p)
def main():
    p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True);p.add_argument('--cases',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--code-commit',required=True);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    cases=json.loads(a.cases.read_text())['cases'];assert len(cases)==72
    frozen={'experiment_id':'PHASE-N-V1-20261021','code_commit':a.code_commit,
        'cases_sha256':hashlib.sha256(a.cases.read_bytes()).hexdigest(),'batch_shapes':[16,4,1],
        'max_new_tokens':256,'scope':'fixed-state real GPU verification/oracle/fallback cost; NOT online serving',
        'no_kv_reuse':True,'oracle_repeats':2,'fault_selection':'all C3 contexts; wrong context is next same-language partner; no outcome selection'}
    save(a.output/'RUN.json',frozen)
    for row in json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())['files']:
        assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256']
    from importlib.metadata import version
    base={'gpu':0,'dtype':'float16','model':str(a.data_root/'models/Qwen3-ASR-1.7B'),
        'manifest':str(a.data_root/'datasets/tc_live_20260906/manifest.json'),
        'microbatch':16,'max_new_tokens':256,'runtime_digest':fingerprint(frozen),
        'allow_execution_context_override':True,'capture_model_inputs':True,'full_sequence_certificate':True}
    workers={};sampler=PowerSampler([0,1],interval=.2);phase_names=[];summary=[];worker_configs=[]
    def start_worker(role,gpu,dtype,budget=256):
        config=dict(base,gpu=gpu,dtype=dtype,max_new_tokens=budget)
        config['runtime_digest']=fingerprint({'code_commit':a.code_commit,'dtype':dtype,'max_new_tokens':budget,
            'model_config_sha256':hashlib.sha256((Path(base['model'])/'config.json').read_bytes()).hexdigest(),
            'manifest_sha256':hashlib.sha256(Path(base['manifest']).read_bytes()).hexdigest(),
            'backend':'transformers-eager','microbatch_limit':16,'greedy':True})
        w=GPUExecutor(role,config);worker_configs.append(config)
        save(a.output/'WORKER_CONFIGS.json',worker_configs);return w
    def compute(worker,jobs,batch):
        rows=[];batches=[]
        for start in range(0,len(jobs),batch):
            real=jobs[start:start+batch];submitted=copy.deepcopy(real)
            # Fixed last-batch layout, charged and recorded; dummy rows not new cases.
            if batch==16:
                while len(submitted)<16:submitted.append({**copy.deepcopy(real[-1]),'dummy_padding_row':True})
            worker.submit(submitted);begin=time.monotonic()
            while True:
                result=worker.poll()
                if result is not None:break
                if time.monotonic()-begin>900:raise TimeoutError('bounded probe batch exceeded 900s')
                time.sleep(.001)
            assert len(result)==len(submitted)
            rows.extend(result[:len(real)]);batches.append({'job_ids':[j['job_id'] for j in real],
                'real_rows':len(real),'submitted_rows':len(submitted),
                'elapsed':max(r['completed_perf'] for r in result)-min(r['started_perf'] for r in result)})
        return rows,batches
    def phase(name,worker,jobs,batch):
        jobs=copy.deepcopy(jobs)
        for j in jobs:
            j['origin_runtime_digest']=j.get('runtime_digest');j['origin_contract_digest']=j.get('contract_digest')
            j['runtime_digest']=worker.ready['runtime_digest'];j['contract_digest']=fingerprint(frozen)
        begin=time.perf_counter();rows,batches=compute(worker,jobs,batch);end=time.perf_counter()
        save(a.output/(name+'.json'),{'phase':name,'jobs':jobs,'results':rows,'batches':batches,
            'started_perf':begin,'completed_perf':end,'wall_seconds':end-begin,'batch_shape':batch})
        phase_names.append(name);save(a.output/'PROGRESS.json',{'phases_completed':phase_names})
        print(json.dumps({'phase':name,'rows':len(rows),'wall_seconds':end-begin}),flush=True);return rows
    def jobs_for(group,kind):
        rows=[]
        for c in group:
            j=copy.deepcopy(c['authority_job']);j['job_id']=f'{kind}-{c["case_id"]}';j['audio_ready_perf']=0.
            j['probe_case_id']=c['case_id'];rows.append(j)
        return rows
    try:
        workers['draft']=start_worker('v1-draft',0,'float16')
        workers['authority']=start_worker('v1-authority',1,'float32')
        for w in workers.values():w.wait_ready()
        save(a.output/'ENVIRONMENT.json',{'software':{k:version(k) for k in ['torch','transformers','qwen-asr']},
            'workers':{k:w.ready for k,w in workers.items()},'source_commit':a.code_commit})
        sampler.start()
        groups={g:[c for c in cases if c['group']==g] for g in ['C1','C2','C3']}
        c3=groups['C3'];draft=phase('C3-extra-root-draft-b16',workers['draft'],jobs_for(c3,'C3draft'),16)
        groups['F2']=[{**c,'case_id':c['case_id']+10000,'group':'F2'} for c in c3]
        wrong_jobs=jobs_for(groups['F2'],'F2draft')
        for i,(c,j) in enumerate(zip(c3,wrong_jobs)):
            partners=[x for x in c3 if x['authority_job']['language']==c['authority_job']['language'] and x['source_id']!=c['source_id']]
            partner=partners[i%len(partners)]
            j['fault_actual_prompt_tokens']=partner['authority_result']['state_tokens']
        wrong=phase('F2-actual-wrong-context-draft-b16',workers['draft'],wrong_jobs,16)
        candidate={c['case_id']:r for c,r in zip(c3,draft)}
        candidate.update({c['case_id']:r for c,r in zip(groups['F2'],wrong)})
        for g in ['C1','C2']:
            for c in groups[g]:
                if c['candidate'] is not None:candidate[c['case_id']]=c['candidate']['result']
        for batch in [16,4,1]:
            for group,values in groups.items():
                jobs=jobs_for(values,f'{group}-oracle-b{batch}')
                oracle=phase(f'{group}-oracle-b{batch}',workers['authority'],jobs,batch)
                repeat=phase(f'{group}-oracle-repeat-b{batch}',workers['authority'],jobs,batch)
                oracle_as_candidate=[{**j,'job_id':j['job_id']+'-selfcheck','audit_rescore_tokens':o['token_ids'],
                    'candidate_state_tokens':o['state_tokens']} for j,o in zip(jobs,oracle)]
                phase(f'{group}-oracle-selfcheck-b{batch}',workers['authority'],oracle_as_candidate,batch)
                phase(f'{group}-oracle-selfcheck-repeat-b{batch}',workers['authority'],oracle_as_candidate,batch)
                present=[(c,j,o,rr) for c,j,o,rr in zip(values,jobs,oracle,repeat) if c['case_id'] in candidate]
                verifyjobs=[]
                for c,j,o,rr in present:
                    proposal=candidate[c['case_id']]
                    verifyjobs.append({**j,'job_id':j['job_id']+'-verify',
                        'audit_rescore_tokens':proposal['token_ids'],'candidate_state_tokens':proposal['state_tokens']})
                checked=phase(f'{group}-verify-b{batch}',workers['authority'],verifyjobs,batch)
                rejected=[j for c,j,o,rr in zip(values,jobs,oracle,repeat) if c['case_id'] not in candidate]
                for c,j,o,rr in zip(values,jobs,oracle,repeat):
                    if c['case_id'] not in candidate:
                        summary.append({'group':group,'case_id':c['case_id'],'source_id':c['source_id'],'batch':batch,
                            'accepted':False,'oracle_exact':None,'candidate_missing':True,
                            'repeat_exact':o['token_ids']==rr['token_ids'] and o['state_tokens']==rr['state_tokens'],
                            'oracle_tokens':len(o['token_ids']),'candidate_tokens':0})
                for (c,j,o,rr),v in zip(present,checked):
                    proposal=candidate[c['case_id']]
                    exact=proposal['token_ids']==o['token_ids'] and v['reconstructed_state_tokens']==o['state_tokens']
                    summary.append({'group':group,'case_id':c['case_id'],'source_id':c['source_id'],'batch':batch,
                        'accepted':v['certificate_accept'],'oracle_exact':exact,
                        'offered_projection_exact':proposal['state_tokens']==o['state_tokens'],
                        'offered_pair_accept':v['offered_pair_accept'],
                        'repeat_exact':o['token_ids']==rr['token_ids'] and o['state_tokens']==rr['state_tokens'],
                        'oracle_tokens':len(o['token_ids']),'candidate_tokens':len(proposal['token_ids'])})
                    if not v['certificate_accept']:rejected.append(j)
                # Complete fixed-row FP32 fallback; no cache retained/reused.
                # Keep original submitted batch layout for exact-mode comparison.
                if rejected:
                    rejected_ids={j['job_id'] for j in rejected};fallback_jobs=[]
                    for offset in range(0,len(jobs),batch):
                        block=jobs[offset:offset+batch]
                        if any(j['job_id'] in rejected_ids for j in block):fallback_jobs.extend(block)
                    phase(f'{group}-full-fallback-b{batch}',workers['authority'],fallback_jobs,batch)
        # GPU stop-negative controls on the already generated C3 candidates.
        controls=[]
        for c,r in zip(c3,draft):
            if len(r['token_ids'])>1:
                j=jobs_for([c],'stop-negative')[0]
                controls.append({**j,'audit_rescore_tokens':r['token_ids'][:-1],
                    'candidate_state_tokens':r['state_tokens'],'control':'remove-final-token'})
        phase('C3-stop-negative-b16',workers['authority'],controls,16)
        # Real cap-mode controls use a separately declared four-token generation budget.
        for w in workers.values():w.close()
        workers={}
        for role,gpu,dtype in [('draft',0,'float16'),('authority',1,'float32')]:
            workers[role]=start_worker('cap-'+role,gpu,dtype,budget=4)
            workers[role].wait_ready()
        capcases=[c3[i] for i in [0,1,12,13]];capjobs=jobs_for(capcases,'cap4')
        capdraft=phase('cap4-draft-b4',workers['draft'],capjobs,4)
        caporacle=phase('cap4-oracle-b4',workers['authority'],capjobs,4)
        phase('cap4-oracle-repeat-b4',workers['authority'],capjobs,4)
        phase('cap4-oracle-selfcheck-b4',workers['authority'],[{**j,'audit_rescore_tokens':r['token_ids'],
            'candidate_state_tokens':r['state_tokens']} for j,r in zip(capjobs,caporacle)],4)
        phase('cap4-verify-b4',workers['authority'],[{**j,'audit_rescore_tokens':r['token_ids'],
            'candidate_state_tokens':r['state_tokens']} for j,r in zip(capjobs,capdraft)],4)
        power=sampler.stop();save(a.output/'power_samples.json',{'samples':sampler.rows,'campaign':power,
            'scope':'whole fixed-state probe power; per-phase integration needed; not online energy saving'})
        save(a.output/'SUMMARY.json',{'status':'COMPLETE','phases':phase_names,'comparisons':summary,
            'false_accepts':sum(r['accepted'] and not r['oracle_exact'] for r in summary),
            'oracle_repeat_disagreements':sum(not r['repeat_exact'] for r in summary),
            'v2_started':False,'kv_reuse':False})
    except BaseException as exc:
        save(a.output/'STOP.json',{'error':repr(exc),'phases':phase_names});raise
    finally:
        sampler.stop()
        for w in workers.values():w.close()
if __name__=='__main__':main()
