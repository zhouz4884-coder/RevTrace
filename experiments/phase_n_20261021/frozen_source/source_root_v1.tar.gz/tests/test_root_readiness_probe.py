"""Passive root preparation controls; CPU fixtures, not serving evidence."""
import importlib.util
from pathlib import Path
from revtrace.root_readiness_probe import RootReadinessScheduler
spec=importlib.util.spec_from_file_location('root_fixture',Path(__file__).with_name('test_live_qwen.py'))
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
def make():
    ref=f.build(barrier='decoupled',count=2);clock=f.Clock()
    cfg=dict(ref.contract,proposal_reconciliation='lazy',display_protocol='canonical-snapshot-v1',
        publish_canonical_display=True,root_readiness_shadow=True,timeout_seconds=10)
    sessions=[{'session_id':s.sid,'audio':s.audio,'source_id':s.source_id,'language':s.language,'offset':s.offset} for s in ref.sessions.values()]
    return RootReadinessScheduler(sessions=sessions,contract=cfg,executors={'proposal':[f.Fake('p',clock,.01)],
        'authority':[f.Fake('a',clock,.001)]},clock=clock,sleep=clock.sleep,emit=lambda e:None)
def test_roots_are_paid_but_never_displayed_or_committed():
    s=make();out=s.run()
    assert out['root_requested']==out['root_completed']>0 and out['root_candidate_admissions']==0
    assert out['fine_window_accounting_complete']
    assert all(e['job_id'].startswith('authority-') for e in s.events if e['kind']=='commit')
    assert not any(e['job_id'].startswith('root-') for e in s.events if e['kind'] in ['display','canonical-display'])
    assert all(ss.state.prompt_tokens==(6,) for ss in s.sessions.values())
def test_root_inputs_equal_frozen_target_authority_inputs():
    s=make();s.run()
    roots={(e['session_id'],e['audio_end_sample']):e for e in s.events if e['kind']=='root-requested'}
    for e in s.events:
        if e['kind']=='enqueue' and e['role']=='authority':
            root=roots[e['session_id'],e['audio_end_sample']]
            assert root['parent']==e['parent'] and root['prompt_tokens']==e['declared_prompt_tokens']
            assert root['chunk_id']==e['chunk_id'] and root['prefix_audio_sha256']==e['prefix_audio_sha256']
def test_same_input_repeat_preserves_canonical_oracle():
    histories=[]
    for _ in range(2):
        s=make();s.run();histories.append([ss.state.prompt_tokens for ss in s.sessions.values()])
    assert histories[0]==histories[1]
