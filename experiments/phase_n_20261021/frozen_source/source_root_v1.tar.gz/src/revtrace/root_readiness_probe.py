"""Passive C3 preparation probe; candidates never enter display or admission."""
from collections import deque
import hashlib
from .live_qwen import LiveQwenScheduler,fingerprint
from .dgft import digest_tokens

class SharedRootWorker:
    """FIFO multiplexing on the SAME existing proposer process/model."""
    def __init__(self,worker,owner):
        self.worker,self.owner=worker,owner;self.name=worker.name
        self.queue=deque();self.running=None;self.native_ready=deque();self.forward=[]
    def _start(self):
        if self.running is None and self.queue:
            self.running=self.queue.popleft();role,jobs=self.running
            self.worker.submit(jobs)
            if role=='root':self.owner._event('root-batch-submitted',worker=self.name,job_ids=[j['job_id'] for j in jobs])
    def submit(self,jobs):self.queue.append(('native',jobs));self._start()
    def submit_roots(self,jobs):self.queue.append(('root',jobs));self._start()
    def tick(self):
        self._start()
        if self.running is None:return
        role,jobs=self.running;rows=self.worker.poll()
        if hasattr(self.worker,'drain_telemetry'):
            for event in self.worker.drain_telemetry():
                if role=='root':self.owner._event('root-worker-status',worker=self.name,status=event['kind'],**{k:v for k,v in event.items() if k!='kind'})
                else:self.forward.append(event)
        if rows is None:return
        assert sorted(r['job_id'] for r in rows)==sorted(j['job_id'] for j in jobs)
        if role=='root':self.owner._receive_roots(jobs,rows)
        else:self.native_ready.append(rows)
        self.running=None;self._start()
    def poll(self):return self.native_ready.popleft() if self.native_ready else None
    def drain_telemetry(self):value,self.forward=self.forward,[];return value
    @property
    def outstanding(self):return self.running is not None or bool(self.queue) or bool(self.native_ready)

class RootReadinessScheduler(LiveQwenScheduler):
    def __init__(self,**kwargs):
        config=kwargs['contract']
        assert config['verification_policy']=='canonical_generate' and config['proposal_barrier']=='decoupled'
        assert config.get('proposal_result_delay_seconds',0)==0 and len(kwargs['executors']['proposal'])==1
        self.root_requested={};self.root_pending=set();self.root_receipts={};self.root_counter=0
        executors=dict(kwargs['executors']);self.root_worker=SharedRootWorker(executors['proposal'][0],self)
        executors['proposal']=[self.root_worker];kwargs['executors']=executors
        super().__init__(**kwargs)
    def _request_roots(self):
        jobs=[]
        for s in self._ready('authority'):
            key=s.sid,s.segment_end
            if key in self.root_requested or s.sid in self.root_pending:continue
            end=min(round(self._end_seconds(s,s.segment_end)*self.sample_rate),len(s.audio)//4)
            start=s.state.audio_frontier_window;self.root_counter+=1
            job={'job_id':f'root-shadow-{s.sid}-{self.root_counter}','session_id':s.sid,'role':'root-draft',
                'source_id':s.source_id,'language':s.language,'parent':s.state.checkpoint_id,
                'parent_prompt_digest':digest_tokens(s.state.prompt_tokens),'prompt_tokens':list(s.state.prompt_tokens),
                'chunk_id':s.segment_start,'end_window':s.segment_end,'audio_start_sample':start,'audio_end_sample':end,
                'audio_ready_perf':self._ready_time(s,s.segment_end),'enqueue_perf':self.clock(),
                'runtime_digest':fingerprint(self.contract['proposal_runtime']),
                'prefix_audio_sha256':hashlib.sha256(s.audio[:end*4]).hexdigest(),
                'interval_audio_sha256':hashlib.sha256(s.audio[start*4:end*4]).hexdigest()}
            self.root_requested[key]=job;self.root_pending.add(s.sid);jobs.append(job)
            self._event('root-requested',**job)
        for offset in range(0,len(jobs),self.contract['microbatch']):
            self.root_worker.submit_roots(jobs[offset:offset+self.contract['microbatch']])
    def _dispatch(self):
        self._request_roots()  # preparation only; never blocks independent authority
        return super()._dispatch()
    def _receive(self):
        self.root_worker.tick()
        return super()._receive()
    def _receive_roots(self,jobs,rows):
        by_id={r['job_id']:r for r in rows}
        for job in jobs:
            row=by_id[job['job_id']];row['received_perf']=self.clock()
            self.root_receipts[job['session_id'],job['end_window']]=(job,row)
            self.root_pending.discard(job['session_id'])
            self._event('root-complete',job_id=job['job_id'],session_id=job['session_id'],end_window=job['end_window'],
                started=row['started_perf']-self.t0,completed=row['completed_perf']-self.t0,received=row['received_perf']-self.t0)
            self._event('root-worker-record',job=job,result=row)
    def run(self):
        result=super().run();serving_elapsed=result['wall_seconds_including_arrival_and_drain']
        while self.root_worker.outstanding:
            if self.clock()-self.t0>self.contract['timeout_seconds']:raise TimeoutError('root shadow drain exceeded fixed bound')
            self.root_worker.tick();self.sleep(.001)
        elapsed=self.clock()-self.t0
        result.update(wall_seconds_including_arrival_and_drain=elapsed,
            audio_seconds_per_wall_second=result['audio_seconds']/elapsed,
            original_serving_drain_seconds=serving_elapsed,root_extra_drain_seconds=elapsed-serving_elapsed,
            root_requested=len(self.root_requested),root_completed=len(self.root_receipts),
            root_token_limit_results=sum(r['hit_token_limit'] for _,r in self.root_receipts.values()),
            root_candidate_admissions=0,shadow_scope='same proposer worker; extra root jobs paid; NO online verification or candidate consumption')
        assert len(self.root_requested)==len(self.root_receipts)
        return result
