"""Three paid C3 preparation trials; no candidate-dependent authority decision."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--code-commit',required=True);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    for r in json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())['files']:assert hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256']
    frozen={'experiment_id':'PHASE-N-V0-C3-LIVE-PREPARATION','code_commit':a.code_commit,'repeats':3,
        'source_pool':'same 12 sources/16 slots','root_scheduling':'earliest logical eligibility; same proposer FIFO, at most one root per session outstanding',
        'new_workers':0,'candidate_consumption':False,'online_verification':False,'kv_reuse':False,
        'baseline':'matched independent-authority T1 v4 coarse decoupled obs1, three repeats'}
    (a.output/'RUN.json').write_text(json.dumps(frozen,indent=2)+'\n');done=[]
    try:
        for repeat in range(3):
            assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).strip()
            name=f'root-shadow-r{repeat}';(a.output/'logs').mkdir(exist_ok=True)
            cmd=[sys.executable,'-u',str(ROOT/'scripts/run_tc_live_qwen.py'),'--model',str(a.data_root/'models/Qwen3-ASR-1.7B'),
                '--manifest',str(a.data_root/'datasets/tc_live_20260906/manifest.json'),'--output',str(a.output/name),'--code-commit',a.code_commit,
                '--study-id',frozen['experiment_id'],'--mode','coarse','--sessions','16','--microbatch','16','--proposal-barrier','decoupled',
                '--proposal-reconciliation','lazy','--display-protocol','canonical-snapshot-v1','--publish-canonical-display',
                '--phase-n-instrumentation','--capture-model-inputs','--root-readiness-shadow',
                '--durable-journal-path',str(a.output/'journals'/(name+'.wal')),'--journal-sync-mode','group_ready']
            with (a.output/'logs'/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            assert r.returncode==0,name+' failed; raw retained'
            done.append(name);(a.output/'PROGRESS.json').write_text(json.dumps({'completed':done,'expected':3},indent=2)+'\n')
            print(json.dumps({'complete':name,'count':len(done)}),flush=True)
        (a.output/'SUMMARY.json').write_text(json.dumps({'status':'COMPLETE','completed':done},indent=2)+'\n')
    except BaseException as exc:
        (a.output/'STOP.json').write_text(json.dumps({'error':repr(exc),'completed':done},indent=2)+'\n');raise
if __name__=='__main__':main()
