"""Prerequisite-gated scouts, fresh formal sensitivity cells and compatible anchors."""
import argparse,fcntl,hashlib,importlib.util,json,random,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(p,x):
    t=p.with_suffix(p.suffix+'.partial');t.write_text(json.dumps(x,indent=2)+'\n');t.replace(p)
def idle():assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True).strip(),'GPU owner active'
def main():
    p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--code-commit',required=True);p.add_argument('--v1-audit',type=Path,required=True);p.add_argument('--auditor',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    lock=(a.output/'RUN.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    gate=json.loads(a.v1_audit.read_text())
    assert gate['decision']=='PASS_BOUNDED_FP32_CERTIFICATION','V1 strict prerequisite unresolved: do not launch T3'
    for r in json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())['files']:
        assert hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256']
    spec=importlib.util.spec_from_file_location('independent_phase_n',a.auditor);auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor)
    manifest_path=a.data_root/'datasets/tc_live_20260906/manifest.json';manifest=json.loads(manifest_path.read_text())
    conditions={'hold1p5':(1.5,1,0),'hold3':(3.,1,0),'sparse6':(6.,6,4),'anchor0':(0.,1,0),'anchor6':(6.,1,0)}
    policies=['legacy','lazy','barrier'];scouts=[(h,p) for h in ['hold1p5','hold3','sparse6'] for p in policies]
    rng=random.Random(20261021);rng.shuffle(scouts)
    frozen={'experiment_id':'PHASE-N-T3-20261021','code_commit':a.code_commit,'seed':20261021,
        'conditions':conditions,'scouts':scouts,'formal_repeats':3,'fresh_zero_six_anchors':True,
        'v1_audit_sha256':hashlib.sha256(a.v1_audit.read_bytes()).hexdigest(),
        'auditor_sha256':hashlib.sha256(a.auditor.read_bytes()).hexdigest(),
        'sparse_scope':'target windows 4 mod 6 select a batch-response hold; all collateral rows explicitly counted; not natural frequency',
        'publication':'canonical-snapshot-v1','capture_model_inputs':False,'blocking_instrumentation':True}
    save(a.output/'RUN.json',frozen);done=[];scout_projections=[]
    def run_one(phase,condition,policy,repeat):
        idle();hold,every,offset=conditions[condition];name=f'{phase}-{condition}-{policy}-r{repeat}'
        dest=a.output/name;(a.output/'logs').mkdir(exist_ok=True)
        command=[sys.executable,'-u',str(ROOT/'scripts/run_tc_live_qwen.py'),'--model',str(a.data_root/'models/Qwen3-ASR-1.7B'),
            '--manifest',str(manifest_path),'--output',str(dest),'--code-commit',a.code_commit,'--study-id',frozen['experiment_id'],
            '--sessions','16','--microbatch','16','--mode','coarse','--proposal-barrier','segment' if policy=='barrier' else 'decoupled',
            '--proposal-reconciliation','legacy' if policy=='legacy' else 'lazy','--display-protocol','canonical-snapshot-v1',
            '--publish-canonical-display','--phase-n-instrumentation','--proposal-result-delay',str(hold),'--delay-every',str(every),
            '--delay-offset',str(offset),'--durable-journal-path',str(a.output/'journals'/(name+'.wal')),'--journal-sync-mode','group_ready']
        with (a.output/'logs'/(name+'.log')).open('w') as log:
            completed=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        assert completed.returncode==0,name+' failed; preserve original'
        proof=auditor.audit(dest,ROOT,manifest);done.append(name)
        save(a.output/'PROGRESS.json',{'completed':done,'expected_total':54,'latest':name})
        print(json.dumps({'completed':name,'count':len(done),'xrt':proof['xrt'],'obsolete':proof['counts'].get('obsolete_publication',0)}),flush=True)
        return proof
    try:
        for condition,policy in scouts:
            proof=run_one('scout',condition,policy,0);scout_projections.append(proof['final_projection'])
        assert len({json.dumps(v,sort_keys=True) for v in scout_projections})==1,'Scout same-rho canonical mismatch; triage before formal'
        save(a.output/'SCOUT_GATE.json',{'decision':'GO_FORMAL_FIXED_PLAN','scouts':done.copy(),
            'same_canonical_projection':True,'no_parameter_retuning':True})
        formal=[]
        for repeat in range(3):
            for condition in ['anchor0','anchor6','hold1p5','hold3','sparse6']:
                order=policies[repeat%3:]+policies[:repeat%3]
                for policy in order:formal.append((condition,policy,repeat))
        save(a.output/'FORMAL_PLAN.json',{'frozen_after_scout_gate':True,'cells':formal,'new_formal_cells':45,
            'planned_before_scout':'RUN.json; no outcome-based workload or threshold choice'})
        for condition,policy,repeat in formal:run_one('formal',condition,policy,repeat)
        save(a.output/'SUMMARY.json',{'status':'COMPLETE','completed':done,'scout_cells':9,'formal_cells':45})
    except BaseException as exc:
        save(a.output/'STOP.json',{'error':repr(exc),'completed':done});raise
    finally:lock.close()
if __name__=='__main__':main()
