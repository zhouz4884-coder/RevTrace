"""CPU test of frozen window-selected batch-response delays, not fault prevalence."""
import importlib.util,queue
from pathlib import Path
spec=importlib.util.spec_from_file_location('sparse_worker',Path(__file__).resolve().parents[1]/'scripts/tc_live_worker.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def test_selection_uses_target_windows_before_outputs():
    worker=object.__new__(m.GPUExecutor);worker.commands=queue.Queue();worker.delay_every=6;worker.delay_offset=4
    worker.submit([{'end_window':1}]);assert not worker._delay_selected
    worker.submit([{'end_window':4}]);assert worker._delay_selected
    worker.submit([{'end_window':10}]);assert worker._delay_selected
    # One response carries a whole batch: collateral rows must be reported.
    worker.submit([{'end_window':3},{'end_window':4}]);assert worker._delay_selected
