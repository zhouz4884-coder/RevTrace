# RevTrace TC review artifact

This archive contains the production transaction code, tests, frozen summary
and selected raw result records, and the scripts needed to audit the claims in
the accompanying IEEE Transactions on Computers manuscript.

Scope boundaries:

- no model weights or redistributable speech corpora are included;
- the archive does not claim to reproduce GPU runs on arbitrary hardware;
- Qwen and Whisper quality estimands are family-specific and never pooled;
- V100 and RTX 3090 timing contracts are not pooled;
- the CPU transaction microbenchmark is host-side protocol-cost evidence, not
  GPU or end-to-end serving evidence.

Quick checks from the repository root:

```powershell
E:\Anaconda\python.exe scripts\validate_tc_transaction_overhead.py
E:\Anaconda\python.exe -m pytest -q
```

See `docs/CLAIM_BOUNDARIES.md` and the JSON/CSV records for exact denominators,
contracts, environment fingerprints, and hashes.
