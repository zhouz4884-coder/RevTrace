# RevTrace IEEE TC submission staging package

The manuscript is formatted as a 12-page IEEE Transactions regular paper. The
two-page supplement contains detailed safety proofs and the host-side protocol
overhead table. The review artifact is supplied because the public repository
is not anonymously accessible at package-build time.

Upload only the whitelisted files in this archive. Do not upload the dormant
FGCS tables, figures, or historical PDFs from the repository.

Before submission, complete the ORCID/address items listed in STATUS.json and
obtain approval from all authors.
