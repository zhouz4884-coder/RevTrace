# Anonymous RevTrace DSN companion, editorial v13

This package is a bounded evidence companion, not a new experiment.
The frozen native confirmation has eight speakers, two policies and two
timing repeats (32 trials); selected histories and all metrics are unchanged.

## What is included

- Exact complete file snapshots and identities of NN4f, its service controller,
  production support, the original endpoint checker, the frozen reporting code,
  and the later recorded-event accounting code.
- Frozen model/data configuration records for all 32 cells, statistical plan,
  byte/asset gates, per-run summaries, paired source effects, complete endpoint
  rows and raw-journal hash indices. Location prefixes in JSON/CSV records are
  remapped to EXPERIMENT_DISK or REPOSITORY; numerical values, hashes, source
  commits and experimental identities are retained. MANIFEST.json records both
  the original and packaged digests. This remapping does not relabel a run.
- Editable matplotlib source, five frozen plotting inputs, and reproduction
  commands. Four figures are in the paper; source8_paired_effects is artifact-only.

## Local checks without models

Use Python 3.12+ with matplotlib and PyMuPDF installed:

    python verify_reported_statistics.py
    python reproduce_figures.py --out output_figures

The first command checks the archived 32-row summary, eight paired source
effects, energy normalization and the predeclared 20,000-resample speaker-paired
bootstrap. It does not remeasure raw endpoints. The second reproduces all four
main figures and the optional paired-effect figure, including PDF/SVG outputs.
Both commands first check every packaged file against MANIFEST.json.

## Materials not included

Model weights, recordings, the author StreamCorrect dependency checkout,
environment caches, and full original journals are not redistributed here.
Raw journals remain on the designated experiment disk; their identifiers,
byte lengths and hashes are indexed here. Running the original full endpoint
checkers or service controllers requires those inputs, dependencies and source
identities, with location mappings set appropriately. These source snapshots
are code evidence; their historical README files are not completion gates.
The actual completed run gates are in the data records. No claim of a complete
one-command service rerun is made by this bounded package.
