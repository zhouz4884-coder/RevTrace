"""Reviewer-facing sourcewise comparison from the current five-policy study."""
from pathlib import Path
import argparse,csv,hashlib,json,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

def short_tag(source_id):
 m=re.search(r'(S\d{4})W',source_id)
 return m.group(1)if m else source_id[-9:-4]

def render(data,out):
 plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],
  'font.size':7.6,'axes.labelsize':7.6,'axes.titlesize':8.2,'axes.linewidth':.65,
  'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7.1,
  'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,
  'axes.spines.right':False,'savefig.dpi':450})
 fig,axes=plt.subplots(1,2,figsize=(7.05,2.46),sharey=True,gridspec_kw={'width_ratios':[1.03,1]})
 fig.subplots_adjust(left=.088,right=.976,top=.79,bottom=.215,wspace=.115)
 policies=[('conservative_s1','Serial','#737C89','^',-.155),
           ('r0s1','Ready-only','#D58A26','s',0.),
           ('r1s1','RevTrace','#245FA5','o',.155)]
 labels=[short_tag(s['source_id'])for s in data['sources']]
 for panel,ax in enumerate(axes):
  for i,source in enumerate(data['sources']):
   if i%2==0:ax.axhspan(i-.48,i+.48,color='#F3F5F8',zorder=0)
   for key,label,color,marker,offset in policies:
    p=source['policies'][key]
    val=100*p['credit_audio_s']/p['offered_audio_s']if panel==0 else p['both_board_J']/p['offered_audio_s']
    reps=[100*r['credit_audio_s']/r['offered_audio_s']if panel==0 else r['both_board_J']/r['offered_audio_s']for r in p['repeats']]
    ax.plot([min(reps),max(reps)],[i+offset,i+offset],color=color,lw=.85,alpha=.6,zorder=2,solid_capstyle='butt')
    for j,v in enumerate(reps):ax.scatter(v,i+offset+(-.062 if j==0 else .062),s=11,marker=marker,facecolors='white',edgecolors=color,lw=.7,zorder=4)
    ax.scatter(val,i+offset,s=27 if key=='r1s1'else 22,marker=marker,facecolors=color,edgecolors='white',lw=.45,zorder=5)
  ax.set_ylim(len(labels)-.48,-.52);ax.set_yticks(range(len(labels)),labels);ax.tick_params(axis='y',length=0,pad=4)
  ax.grid(axis='x',color='#DCE1E8',lw=.5,zorder=0)
  ax.set_title(('(a) Timely progress: higher is better'if panel==0 else'(b) Service energy: lower is better'),loc='left',fontweight='bold',pad=7)
 axes[0].set_xlim(-2,103);axes[0].set_xticks([0,25,50,75,100]);axes[0].set_xlabel('Dual-deadline audio coverage (%)');axes[0].set_ylabel('Speaker',labelpad=7)
 allJ=[r['both_board_J']/r['offered_audio_s']for s in data['sources']for p in s['policies'].values()for r in p['repeats']]
 lo=np.floor((min(allJ)-15)/50)*50;hi=np.ceil((max(allJ)+15)/50)*50
 axes[1].set_xlim(lo,hi);axes[1].set_xticks(np.arange(lo,hi+1,100));axes[1].set_xlabel('Two-board energy (J per offered audio-second)')
 handles=[Line2D([],[],color=c,marker=m,linestyle='none',markerfacecolor=c,markeredgecolor='white',markersize=5.2,label=l)for k,l,c,m,o in policies]
 fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.995),ncol=3,frameon=False,handletextpad=.45,columnspacing=2.0)
 out.mkdir(parents=True,exist_ok=True)
 for ext in('pdf','svg','png'):fig.savefig(out/('native_comparison.'+ext),bbox_inches=None,pad_inches=.02,metadata={'Creator':'RevTrace figure renderer'}if ext=='pdf'else None)
 plt.close(fig)

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();data=json.loads(a.data.read_bytes())
 assert data['study']=='native.factorial'and data['trials']==80 and len(data['sources'])==8
 for policy,target in [('conservative_s1',55.5),('r0s1',58.5),('r1s1',129.96)]:
  assert abs(sum(s['policies'][policy]['credit_audio_s']for s in data['sources'])-target)<1e-8
  assert abs(sum(s['policies'][policy]['offered_audio_s']for s in data['sources'])-137.864125)<1e-8
  assert all(len(s['policies'][policy]['repeats'])==2 for s in data['sources'])
 for i,s in enumerate(data['sources']):
  for policy in('conservative_s1','r0s1','r1s1'):
   pr=s['policies'][policy];assert abs(sum(r['credit_audio_s']for r in pr['repeats'])-pr['credit_audio_s'])<1e-9
 render(data,a.out)
 print(json.dumps({'figure':'native_comparison','sources':8,'policies':3,'data_sha256':hashlib.sha256(a.data.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
