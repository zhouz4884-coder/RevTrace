# Manuscript source

This directory compiles the accompanying anonymous manuscript. Relative source
filenames and cross-reference keys use stable descriptive names. Manuscript
wording, mathematics, citations, numerical results and supplied figures are
unchanged. Reviewer comments and earlier manuscripts are not included.

Use an installed TeX distribution providing IEEEtran, pdfTeX and BibTeX:

```
pdflatex -no-shell-escape -interaction=nonstopmode main.tex
bibtex main
pdflatex -no-shell-escape -interaction=nonstopmode main.tex
pdflatex -no-shell-escape -interaction=nonstopmode main.tex
```

Figures are included as vector PDFs. The experiment artifact provides numeric
inputs and reproduction instructions separately. The native per-speaker plot
uses the same five-policy, eighty-trial workload as the native main table.
Its three displayed policies retain whole supported views. To redraw it:

```
python figures/render_native_comparison.py --data figures/native_comparison_data.json --out figures
```
